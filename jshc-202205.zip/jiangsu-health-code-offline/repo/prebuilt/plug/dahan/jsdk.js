/*
 *jssdk jsapi所在服务器域名，无需追加'http://'或'https://'
 */
var urldomain = 'www.jszwfw.gov-cn-blocked.au/jmopen';
// var urldomain = '172.16.8.108:8848';
//var urldomain = 'hc8489.uicp.io:36338';

function containerType() {
    var sUserAgent = navigator.userAgent.toLowerCase();
    var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
    var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
    var bIsMidp = sUserAgent.match(/midp/i) == "midp";
    var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
    var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
    var bIsAndroid = sUserAgent.match(/android/i) == "android";
    var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
    var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
    var bIsApp = sUserAgent.indexOf('hanweb') > -1;
    var bIsdingding = sUserAgent.indexOf('dingtalk') > -1;
    var bIsWechat = sUserAgent.indexOf('micromessenger') > -1;
    var bIsAlipay = sUserAgent.indexOf('alipayclient') > -1;

    if (bIsApp) {
        return "hanweb";
    } else if (bIsWechat) {
        return "wechat";
    } else if (bIsAlipay) {
        return "Alipay";
    } else if (bIsdingding) {
        return "dingtalk";
    } else {
        return "web";
    }
}
var container = containerType();
var tmpTag = 'https:' == document.location.protocol ? true : false;

if (container == 'hanweb') {
    if (tmpTag == true) {
        if (typeof $ == 'undefined') {
            document.write('<script type="text/javascript" src="jssdk/jquery-1.8.3.min.js"></script>');
        }
        document.write('<script type="text/javascript" src="jssdk/md5.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/sha1.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/js/indexnew.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/jmportal_SDK.js"></script>');
    } else {
        if (typeof $ == 'undefined') {
            document.write('<script type="text/javascript" src="jssdk/jquery-1.8.3.min.js"></script>');
        }
        document.write('<script type="text/javascript" src="jssdk/md5.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/sha1.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/js/indexnew.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/jmportal_SDK.js"></script>');
    }

} else if (container == 'wechat') {

    if (tmpTag == true) {
        if (typeof $ == 'undefined') {
            document.write('<script type="text/javascript" src="jssdk/jquery-1.8.3.min.js"></script>');
        }
        //      document.write('<script type="text/javascript" src="https://res.wx.qq-com-blocked.au/open/js/jweixin-1.3.2.js"></script>');

        document.write('<script src="https://res.wx.qq-com-blocked.au/open/js/jweixin-1.0.0.js"></script>');
        document.write('<script type="text/javascript" src="https://api.map.baidu-com-blocked.au/api?v=3.0&ak=xOWZlWcTZPK84VcK3Ixzqq9wQ6arTUry"></script>');
        document.write('<script type="text/javascript" src="jssdk/sha1.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/md5.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/alipayjs/aes.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/alipayjs/pad-nopadding.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/wechatjs/indexnew.js"></script>');


    } else {
        if (typeof $ == 'undefined') {
            document.write('<script type="text/javascript" src="jssdk/jquery-1.8.3.min.js"></script>');
        }
        document.write('<script type="text/javascript" src="http://api.map.baidu-com-blocked.au/api?v=3.0&ak=xOWZlWcTZPK84VcK3Ixzqq9wQ6arTUry"></script>');
        //      document.write('<script src="http://res.wx.qq-com-blocked.au/open/js/jweixin-1.3.2.js"></script>');

        document.write('<script src="http://res.wx.qq-com-blocked.au/open/js/jweixin-1.0.0.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/sha1.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/md5.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/alipayjs/aes.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/alipayjs/pad-nopadding.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/wechatjs/indexnew.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/alipayjs/md5.js"></script>');
    }

} else if (container == 'dingtalk') {

    if (tmpTag == true) {
        if (typeof $ == 'undefined') {
            document.write('<script type="text/javascript" src="jssdk/jquery-1.8.3.min.js"></script>');
        }
        document.write('<script type="text/javascript" src="jssdk/md5.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/sha1.js"></script>');
        document.write('<script src="https://g.alicdn.com/dingding/open-develop/1.6.9/dingtalk.js"></script>');
        document.write('<script type="text/javascript" src="https://api.map.baidu-com-blocked.au/api?v=2.0&ak=xOWZlWcTZPK84VcK3Ixzqq9wQ6arTUry"></script>');
        document.write('<script type="text/javascript" src="jssdk/dingtalkjs/indexnew.js"></script>');

    } else {
        if (typeof $ == 'undefined') {
            document.write('<script type="text/javascript" src="jssdk/jquery-1.8.3.min.js"></script>');
        }
        document.write('<script type="text/javascript" src="jssdk/md5.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/sha1.js"></script>');
        document.write('<script type="text/javascript" src="http://api.map.baidu-com-blocked.au/api?v=2.0&ak=xOWZlWcTZPK84VcK3Ixzqq9wQ6arTUry"></script>');
        document.write('<script src="http://g.alicdn.com/dingding/open-develop/1.6.9/dingtalk.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/dingtalkjs/indexnew.js"></script>');
    }

} else if (container == 'Alipay') {
    if (tmpTag == true) {
        if (typeof $ == 'undefined') {
            document.write('<script type="text/javascript" src="jssdk/jquery-1.8.3.min.js"></script>');
        }
        document.write('<script type="text/javascript" src="http://gw.alipayobjects.com/as/g/h5-lib/alipayjsapi/3.1.1/alipayjsapi.min.js"></script>');
        document.writeln('<script src="https://appx/web-view.min.js"' + '>' + '<' + '/' + 'script>');
        document.write('<script type="text/javascript" src="https://api.map.baidu-com-blocked.au/api?v=2.0&ak=xOWZlWcTZPK84VcK3Ixzqq9wQ6arTUry"></script>');
        document.write('<script type="text/javascript" src="jssdk/alipayjs/aes.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/md5.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/sha1.js"></script>');

        document.write('<script type="text/javascript" src="jssdk/alipayjs/pad-nopadding.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/alipayjs/indexnew.js"></script>');

    } else {
        if (typeof $ == 'undefined') {
            document.write('<script type="text/javascript" src="jssdk/jquery-1.8.3.min.js"></script>');
        }
        document.write('<script type="text/javascript" src="http://gw.alipayobjects.com/as/g/h5-lib/alipayjsapi/3.1.1/alipayjsapi.min.js"></script>');
        document.writeln('<script src="https://appx/web-view.min.js"' + '>' + '<' + '/' + 'script>');
        document.write('<script type="text/javascript" src="http://api.map.baidu-com-blocked.au/api?v=2.0&ak=xOWZlWcTZPK84VcK3Ixzqq9wQ6arTUry"></script>');
        document.write('<script type="text/javascript" src="jssdk/alipayjs/aes.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/md5.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/sha1.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/alipayjs/pad-nopadding.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/alipayjs/indexnew.js"></script>');
    }

} else {
    if (tmpTag == true) {
        document.write('<script type="text/javascript" src="https://api.map.baidu-com-blocked.au/api?v=3.0&ak=xOWZlWcTZPK84VcK3Ixzqq9wQ6arTUry"></script>');
        if (typeof $ == 'undefined') {
            document.write('<script type="text/javascript" src="jssdk/jquery-1.8.3.min.js"></script>');
        }
        document.write('<script type="text/javascript" src="jssdk/md5.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/sha1.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/alipayjs/aes.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/alipayjs/pad-nopadding.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/wechatjs/brower.js"></script>');
    } else {
        document.write('<script type="text/javascript" src="http://api.map.baidu-com-blocked.au/api?v=3.0&ak=xOWZlWcTZPK84VcK3Ixzqq9wQ6arTUry"></script>');
        if (typeof $ == 'undefined') {
            document.write('<script type="text/javascript" src="jssdk/jquery-1.8.3.min.js"></script>');
        }
        document.write('<script type="text/javascript" src="jssdk/md5.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/sha1.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/alipayjs/aes.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/alipayjs/pad-nopadding.js"></script>');
        document.write('<script type="text/javascript" src="jssdk/wechatjs/brower.js"></script>');
    }

}/*Already patched - 1e0fdd9305a1*/
