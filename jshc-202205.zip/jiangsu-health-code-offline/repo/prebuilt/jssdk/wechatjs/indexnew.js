//var urldomain = 'jmpotal.hanweb.com/jmopen';
var tmpTag = 'https:' == document.location.protocol ? true : false;

var lightAppJssdk;
if(!lightAppJssdk) lightAppJssdk = {};
var tokens = localStorage.getItem("token");
if(tokens  != undefined){
	localStorage.setItem("tokenjssdk", tokens);
} else {
	localStorage.removeItem("tokenjssdk");
}
lightAppJssdk.dataUtil = (function() {
	//保存数据
	function setItem(option) {
		var i = 0;
		var keys = option.key;
		localStorage.setItem(option.key, option.value);
		setTimeout(function() {
			if(i == 0) {
				option.success('保存成功');
			}
		}, 1500);

	};

	//读取数据
	function getItem(option) {
		var data = localStorage.getItem(option.key);
		option.success(localStorage.getItem(option.key));

	};

	//删除数据
	function removeItem(option) {
		var data = localStorage.getItem(option.key);
		if(data != undefined) {
			localStorage.removeItem(option.key);
			setTimeout(function() {
				option.success('删除成功');
			}, 1500);
		} else {
			option.success('key为空');
		}

	};

	return {
		setItem: setItem,
		getItem: getItem,
		removeItem: removeItem
	}
})();
//获取用户信息
lightAppJssdk.user = (function() {
	//获得用户信息
	function getTicket(option) {
		var Request = GetRequest();
		if(location.href.indexOf("token=") == -1) {
			if(location.href.indexOf("ticket=") == -1) {
				//链接后无票据
				var token = localStorage.getItem("tokenjssdk");
				if(token == null) {
					//					alert('container：wx;result:未登录');
					option.success("未登录");
				} else {
					token = decodeURI(token);

					var data = {
						token: token
					}
					var requesturl;
					if(tmpTag == true) {
						requesturl = "https://www.jszwfw.gov-cn-blocked.au/jmopen/interfaces/UserAuth/getTicket.do";
					} else {
						requesturl = "http://www.jszwfw.gov-cn-blocked.au/jmopen/interfaces/UserAuth/getTicket.do";
					}
					lightAppJssdk.request.request({
						url: requesturl,
						data: data,
						header: '',
						type: 'post', //HTTP请求类型
						async: false, //同步
						timeout: 10000, //超时时间设置为10秒；
						success: function(data) {
							//							alert('container：wx;result:' + JSON.stringify(data));
							option.success(JSON.stringify(data));
						},
						error: function(e) {

						}
					});
				}
			} else {
				var tickets = location.href.split("ticket=")[1].split("&")[0];
				var ticket = {
					result: "true",
					ticket: tickets
				}
				//				alert('container：wx;result:' + JSON.stringify(ticket));
				option.success(JSON.stringify(ticket));
			}

		} else {
			var token = location.href.split("token=")[1].split("&")[0];
			token = token.split("#")[0];

			localStorage.setItem("tokenjssdk", token);

			var data = {
				token: token
			}
			var requesturl;
			if(tmpTag == true) {
				requesturl = "https://www.jszwfw.gov-cn-blocked.au/jmopen/interfaces/UserAuth/getTicket.do";
			} else {
				requesturl = "http://www.jszwfw.gov-cn-blocked.au/jmopen/interfaces/UserAuth/getTicket.do";
			}
			try {
				lightAppJssdk.request.request({
					url: requesturl,
					data: data,
					header: '',
					type: 'post', //HTTP请求类型
					async: false, //同步
					timeout: 10000, //超时时间设置为10秒；
					success: function(data) {
						option.success(JSON.stringify(data));
					},
					error: function(e) {}
				});
			} catch(e) {}

		}

	};
	//登录
	function loginapp(option) {
		//		alert('container：wx;action:loginapp');
		if(location.href.indexOf("token=") == -1) {
			var token = window.localStorage.token;

			if(token == "" || typeof(token) == "undefined") { //未登录
				if(tmpTag == true) {
					window.location.href = "https://www.jszwfw.gov-cn-blocked.au/jmopen/jssdk/wechatlogin/login.html?location=" + window.location;

				} else {
					window.location.href = "http://www.jszwfw.gov-cn-blocked.au/jmopen/jssdk/wechatlogin/login.html?location=" + window.location;

				}

			} else {
				option.success("已登录");
			}
		} else {
			option.success("已登录");
		}

	};

	//注销
	function logout(option) {
		window.localStorage.token = "";
		option.success("注销成功");
	};
	return {
		getTicket: getTicket,
		loginapp: loginapp,
		logout: logout

	}

})();

function requemedia(option) {
	var timestamp = (new Date()).valueOf();
	var uuid = 'lightapp-rebellion';
	var tokenuuidmd5 = timestamp + '318qwe' + uuid;
	var tokenuuid = hex_md5(tokenuuidmd5);
	var urlcan = window.location.href;
	var url;
	if(tmpTag == true) {
		//  	   urlcan=urlcan.replace("https://","");
		url = 'https://' + urldomain + '/interfaces/getmediaurl.do?' + 'urlString=' + urlcan + '&serid=' + option.mediaid;
		//      urlcan=urlcan.replace("https://","");

	} else {
		//      urlcan=urlcan.replace("http://","");
		url = 'http://' + urldomain + '/interfaces/getmediaurl.do?' + 'urlString=' + urlcan + '&serid=' + option.mediaid;
		//      urlcan=urlcan.replace("http://","");
	}
	urlcan = urlcan.split("?")[0];
	var date = {
		udid: uuid,
		uniquecode: timestamp,
		tokenuuid: tokenuuid
	};
	$.ajax({
		url: url,
		data: date,
		dataType: 'json', //服务器返回json格式数据
		type: 'post', //HTTP请求类型
		async: false, //同步
		timeout: 10000, //超时时间设置为10秒；
		success: function(data) {
			if(data.result == 'false') {
				//           alert(data.msg);
			} else {
				option.success(data.mediaurl);
			}
		},
		error: function(e) {
			//           alert('媒体服务器返回的数据cuowu+++++++'+JSON.stringify(e));
		}
	});
};
lightAppJssdk.navi = (function() {
	a

})
//页面控制
lightAppJssdk.navigation = (function() {

	//关闭当前窗口
	function close(option) {
		wx.closeWindow();

	};
	return {
		close: close
	}

})();
//位置
lightAppJssdk.map = (function() {
	function getLocation(option) {
		wx.getLocation({
			success: function(res) {
				option.success(JSON.stringify(res));
			},
			cancel: function(res) {
				option.fail('用户拒绝授权获取地理位置');
			}
		});

	};

	function locate(option) {
		wx.openLocation({
			latitude: 0, // 纬度，浮点数，范围为90 ~ -90
			longitude: 0, // 经度，浮点数，范围为180 ~ -180。
			name: '', // 位置名
			address: '', // 地址详情说明
			scale: 1, // 地图缩放级别,整形值,范围从1~28。默认为最大
			infoUrl: '' // 在查看位置界面底部显示的超链接,可点击跳转
		});
	};
	return {
		getLocation: getLocation,
		locate: locate
	}
})();

//设备
lightAppJssdk.device = (function() {

	function networkType(option) {
		wx.getNetworkType({
			success: function(res) {
				option.success(res.networkType);
			},
			fail: function(res) {
				option.fail(JSON.stringify(res));
			}
		});
	};

	function scan(option) {
		wx.scanQRCode({
			needResult: 1,
			desc: 'scanQRCode desc',
			success: function(res) {
				option.success(JSON.stringify(res));
			}
		});
	};
	return {
		networkType: networkType,
		scan: scan
	}
})();
//提示信息
// 弹窗
lightAppJssdk.notification = (function() {

	function alert(option) {
		alert();

	};

	function confirm(option) {

	};

	function prompt(option) {

	};

	function actionSheet(option) {

	};

	function showPreloader(option) {

	};

	function hidePreloader(option) {

	};

	function toast(option) {

	};
	
	function showAuthAlert(option) {
	
	};

	return {
		alert: alert,
		confirm: confirm,
		prompt: prompt,
		actionSheet: actionSheet,
		showPreloader: showPreloader,
		hidePreloader: hidePreloader,
		toast: toast,
		showAuthAlert:showAuthAlert,
	}

})();

//选取图片
var images = {
	result: 'false',
	localId: [],
	picPath: []
};
var voice = {
	localId: '',
	serverId: ''
};
//媒体资源
lightAppJssdk.media = (function() {
	//选取图片
	function chooseImage(option) {
		wx.chooseImage({
			success: function(res) {
				images.localId = res.localIds;
				//上传
				if(images.localId.length == 0) {
					return;
				}
				var i = 0,
					length = images.localId.length;
				var picPathArr = new Array();

				function upload() {
					wx.uploadImage({
						localId: images.localId[i],
						success: function(res) {
							i++;

							if(res.serverId == undefined) {
								return;
							}
							requemedia({
								mediaid: res.serverId,
								success: function(data) {
									picPathArr[i - 1] = data;
									if(i < length) {
										upload();
									} else {
										images.result = 'true';
										images.picPath = picPathArr;
										option.success(images);
									}
								}
							});
						},
						fail: function(res) {
							//                                                   alert(JSON.stringify(res));
						}
					});
				}
				upload();
			}
		});
	};
	//音频
	//开始录音
	function startVoice(option) {
		wx.startRecord({
			cancel: function() {
				//                                    alert('用户拒绝授权录音');
			}
		});
	};
	//停止录音
	function stopVoice(option) {

		wx.stopRecord({
			success: function(res) {
				wx.uploadVoice({
					localId: res.localIds,
					success: function(res) {

						voice.serverId = res.serverId;
						var mediaurl = requemedia(res.serverId);
						option.success(mediaurl);
					}
				});

			},
			fail: function(res) {
				//                                   alert(JSON.stringify(res));
			}
		});
	};
	//开始播放
	function playVoice(option) {
		wx.playVoice({
			serverId: voice.serverId // 需要播放的音频的本地ID，由stopRecord接口获得
		});
	};

	//停止播放
	function stopPlayVoice(option) {
		wx.stopVoice({
			serverId: voice.serverId // 需要停止的音频的本地ID，由stopRecord接口获得
		});
	};
	//语音转文字
	function translateVoice(option) {
		wx.translateVoice({
			localId: res.localIds, // 需要识别的音频的本地Id，由录音相关接口获得
			isShowProgressTips: 1, // 默认为1，显示进度提示
			success: function(res) {
				option.success(res.translateResult);
			}
		});
	};
	return {
		chooseImage: chooseImage,
		startVoice: startVoice,
		stopVoice: stopVoice,
		playVoice: playVoice,
		stopPlayVoice: stopPlayVoice,
		translateVoice: translateVoice
	}

})();
//工具类
lightAppJssdk.util = (function() {
	//分享到朋友圈
	function shareTimeline(option) {
		wx.onMenuShareTimeline({
			title: option.title, // 分享标题
			link: option.link, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
			imgUrl: option.title, // 分享图标
			success: function() {
				option.success();
			},
			cancel: function() {
				// 用户取消分享后执行的回调函数
				option.fail();
			}
		});

	};
	//分享给朋友
	function shareShareAppMessage(option) {
		wx.onMenuShareAppMessage({
			title: option.title, // 分享标题
			desc: option.desc, // 分享描述
			link: option.link, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
			imgUrl: option.imgUrl, // 分享图标
			type: option.type, // 分享类型,music、video或link，不填默认为link
			dataUrl: option.dataUrl, // 如果type是music或video，则要提供数据链接，默认为空
			success: function() {
				option.success();
			},
			cancel: function() {
				option.fail();
			}
		});

	};
	//分享到QQ
	function shareShareQQ(option) {
		wx.onMenuShareQQ({
			title: option.title, // 分享标题
			desc: option.desc, // 分享描述
			link: option.link, // 分享链接
			imgUrl: option.imgUrl, // 分享图标
			success: function() {
				option.success();
			},
			cancel: function() {
				option.fail();
			}
		});

	};
	//分享到QQ空间
	function shareShareQZone(option) {
		wx.onMenuShareQZone({
			title: option.title, // 分享标题
			desc: option.desc, // 分享描述
			link: option.link, // 分享链接
			imgUrl: option.imgUrl, // 分享图标
			success: function() {
				// 用户确认分享后执行的回调函数
				option.success();

			},
			cancel: function() {
				// 用户取消分享后执行的回调函数
				option.fail();
			}
		});

	};
	return {
		shareTimeline: shareTimeline,
		shareShareAppMessage: shareShareAppMessage,
		shareShareQQ: shareShareQQ,
		shareShareQZone: shareShareQZone
	}
})();
wx.ready(function() {
	// 1 判断当前版本是否支持指定 JS 接口，支持批量判断
	wx.checkJsApi({
		jsApiList: [
			'checkJsApi',
			'onMenuShareTimeline',
			'onMenuShareAppMessage',
			'onMenuShareQQ',
			'onMenuShareWeibo',
			'onMenuShareQZone',
			'hideMenuItems',
			'showMenuItems',
			'hideAllNonBaseMenuItem',
			'showAllNonBaseMenuItem',
			'translateVoice',
			'startRecord',
			'stopRecord',
			'onVoiceRecordEnd',
			'playVoice',
			'onVoicePlayEnd',
			'pauseVoice',
			'stopVoice',
			'uploadVoice',
			'downloadVoice',
			'chooseImage',
			'previewImage',
			'uploadImage',
			'downloadImage',
			'getNetworkType',
			'openLocation',
			'getLocation',
			'hideOptionMenu',
			'showOptionMenu',
			'closeWindow',
			'scanQRCode',
			'chooseWXPay',
			'openProductSpecificView',
			'addCard',
			'chooseCard',
			'openCard'
		],
		success: function(res) {

		}
	});
});
wx.error(function(res) {});

var appIdString;
var tokenString;
var nonceString;
var ticket;
var timestamps;
requesttoken();

function requesttoken() {
	timestamps = (new Date()).valueOf();
	var uuid = 'lightapp-rebellion';
	var tokenuuidmd5 = timestamps + '318qwe' + uuid;
	var tokenuuid = hex_md5(tokenuuidmd5);
	var urlcan = window.location.href;

	var url;
	if(tmpTag == true) {
		//      urlcan=urlcan.replace("https://","");
		url = 'https://' + urldomain + '/interfaces/getwechatticket.do';
	} else {
		//      urlcan=urlcan.replace("http://","");
		url = 'http://' + urldomain + '/interfaces/getwechatticket.do';
	}
	urlcan = urlcan.split("?")[0];
	var date = {
		udid: uuid,
		uniquecode: timestamps,
		tokenuuid: tokenuuid,
		urlString: urlcan
	};
	$.ajax({
		url: url,
		data: date,
		dataType: 'json', //服务器返回json格式数据
		type: 'post', //HTTP请求类型
		async: false, //同步
		timeout: 10000, //超时时间设置为10秒；
		success: function(data) {
			if(data.result == false) {
				//           alert(data.message);
			} else {
				appIdString = data.appid;
				tokenString = data.access_token;
				nonceString = data.noncestr;
				ticket = data.ticket;
				//				wxconfig();
			}
		},
		error: function(e) {
			//           alert('tokenerror'+JSON.stringify(e));
		}
	});
};

function wxconfig() {

	var urlString = window.location.href;

	var signatureString = 'jsapi_ticket=' + ticket + '&noncestr=' + nonceString + '&timestamp=' + timestamps + '&url=' + urlString;

	var signature = hex_sha1(signatureString);
	wx.config({
		debug: false,
		appId: appIdString,
		timestamp: timestamps,
		nonceStr: nonceString,
		signature: signature,
		jsApiList: [
			'checkJsApi',
			'onMenuShareTimeline',
			'onMenuShareAppMessage',
			'onMenuShareQQ',
			'onMenuShareWeibo',
			'onMenuShareQZone',
			'hideMenuItems',
			'showMenuItems',
			'hideAllNonBaseMenuItem',
			'showAllNonBaseMenuItem',
			'translateVoice',
			'startRecord',
			'stopRecord',
			'onVoiceRecordEnd',
			'playVoice',
			'onVoicePlayEnd',
			'pauseVoice',
			'stopVoice',
			'uploadVoice',
			'downloadVoice',
			'chooseImage',
			'previewImage',
			'uploadImage',
			'downloadImage',
			'getNetworkType',
			'openLocation',
			'getLocation',
			'hideOptionMenu',
			'showOptionMenu',
			'closeWindow',
			'scanQRCode',
			'chooseWXPay',
			'openProductSpecificView',
			'addCard',
			'chooseCard',
			'openCard'
		]
	});
};
/**
 * 获取url中"?"符后的字串
 */
function GetRequest() {
	var url = window.location.search;
	var theRequest = new Object();
	if(url.indexOf("?") != -1) {
		var str = url.substr(1);
		strs = str.split("&");
		for(var i = 0; i < strs.length; i++) {
			theRequest[strs[i].split("=")[0]] = (strs[i].split("=")[1]);
		}
	}
	return theRequest;
};

function Encrypt(word) {
	var key = CryptoJS.enc.Utf8.parse('jmopenHanweb1567');
	var iv = CryptoJS.enc.Latin1.parse('jmopenHanweb1567');
	var srcs = CryptoJS.enc.Utf8.parse(word);
	var encrypted = CryptoJS.AES.encrypt(srcs, key, {
		iv: iv,
		mode: CryptoJS.mode.CBC,
		padding: NoPadding
	});
	return encrypted.toString();
};
//网络请求
lightAppJssdk.request = (function() {

	function request(option) {
		var dataa;
		var header;
		var async;
		var timeout;
		if(option.async != undefined) {
			async = option.async;
		} else {
			async = false;
		}
		if(option.timeout != undefined) {
			timeout = option.timeout;
		} else {
			timeout = 10000;
		}
		if(option.data == '' || option.data == undefined) {
			dataa = '';
		} else {
			dataa = JSON.stringify(option.data);
			dataa = dataa.replace(/\%/g, '%25').replace(/\#/g, '%23').replace(/\+/g, '%2B').replace(/\//g, '%2F').replace(/\?/g, '%3F').replace(/\&/g, '%26').replace(/\=/g, '%3D')

		}
		if(option.header == '' || option.header == undefined) {
			header = '';
		} else {
			header = JSON.stringify(option.header);
		}
		var url;
		if(tmpTag == true) {
			url = 'https://' + urldomain + '/interfaces/wxTransferPort.do';
		} else {
			url = 'http://' + urldomain + '/interfaces/wxTransferPort.do';
		}
		dataa = dataa.replace(/{/g, "dhzkh");
		dataa = dataa.replace(/}/g, "dhykh");
		if(option.dataType == undefined) {
			option.dataType = 'jsonp';
		}
		var dat = {
			requestUrl: option.url,
			datas: dataa,
			heads: header
		};
		$.ajax({
			url: url,
			data: dat,
			xhrFields: {
				withCredentials: true
			},
			crossDomain: true,
			dataType: option.dataType,
			jsonp: 'callback',
			//                              dataType: option.dataType, //服务器返回json格式数据
			type: 'get', //HTTP请求类型
			async: async, //同步
			timeout: timeout, //超时时间设置为10秒；
			success: function(data) {
				option.success(data);
			},
			error: function(e) {
				option.fail(e);
			}
		});
	};
	return {
		request: request
	}
})();
//GetCurrentLocation('');

function GetCurrentLocation(fuc) {
	var timestamp = (new Date()).valueOf();
	var uuid = 'lightapp-rebellion';
	var tokenuuidmd5 = timestamp + '318qwe' + uuid;
	var tokenuuid = hex_md5(tokenuuidmd5);
	var url;
	var url1;
	var urlc = window.location.href;

	if(tmpTag == true) {
		url = 'https://' + urldomain + '/interfaces/getAppSecret.do?' + 'appUrl=' + urlc;
		url1 = 'https://' + urldomain + '/interfaces/statisticsUserData.do';
	} else {
		url = 'http://' + urldomain + '/interfaces/getAppSecret.do?' + 'appUrl=' + urlc;
		url1 = 'http://' + urldomain + '/interfaces/statisticsUserData.do';
	}
	var value = localStorage.getItem("citynamehanweb");
	if(typeof value == 'undefined' || value == null) {
		var geolocation = new BMap.Geolocation();
		geolocation.getCurrentPosition(function(r) {
			var region;
			if(this.getStatus() == BMAP_STATUS_SUCCESS) { //定位成功
				var city = r.address.city;
				region = city.replace("市", "");
				localStorage.setItem("citynamehanweb", region);
			} else { //定位失败
				region = '南京';
			}
			var date = {
				udid: uuid,
				uniquecode: timestamp,
				tokenuuid: tokenuuid
			};

			$.ajax({
				url: url,
				data: date,
				type: 'post', //HTTP请求类型
				async: false, //同步
				timeout: 10000, //超时时间设置为10秒；
				success: function(data) {
					data = JSON.parse(data);
					var json = {
						"key": data.key,
						"secret": data.secret,
						"starttime": timestamp,
						"statisticsType": "1",
						"terminalType": "1",
						"channel": "2",
						"netWork": "4G",
						"region": region,
						udid: uuid,
						uniquecode: timestamp,
						tokenuuid: tokenuuid
					};

					$.ajax({
						url: url1,
						data: json,
						type: 'post', //HTTP请求类型
						async: false, //同步
						timeout: 10000, //超时时间设置为10秒；
						success: function(data) {},
						error: function(e) {}
					});
				},
				error: function(e) {}
			});
		}, {
			enableHighAccuracy: true
		});
	} else {
		var date = {
			udid: uuid,
			uniquecode: timestamp,
			tokenuuid: tokenuuid
		};
		$.ajax({
			url: url,
			data: date,
			type: 'post', //HTTP请求类型
			async: false, //同步
			timeout: 10000, //超时时间设置为10秒；
			success: function(data) {
				data = JSON.parse(data);
				var json = {
					"key": data.key,
					"secret": data.secret,
					"starttime": timestamp,
					"statisticsType": "1",
					"terminalType": "1",
					"channel": "2",
					"netWork": "4G",
					"region": value,
					udid: uuid,
					uniquecode: timestamp,
					tokenuuid: tokenuuid
				};
				$.ajax({
					url: url1,
					data: json,
					type: 'post', //HTTP请求类型
					async: false, //同步
					timeout: 10000, //超时时间设置为10秒；
					success: function(data) {

					},
					error: function(e) {}
				});
			},
			error: function(e) {}
		});
	}

};