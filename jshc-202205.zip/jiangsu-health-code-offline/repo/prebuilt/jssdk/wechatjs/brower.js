var tmpTag = 'https:' == document.location.protocol ? true : false;
var lightAppJssdk;
if(!lightAppJssdk) lightAppJssdk = {};
var urldomain1 = 'www.jszwfw.gov-cn-blocked.au/jmopen';

function request(b) {
	var c;
	var d;
	var f;
	var g;
	if(b.async != undefined) {
		f = b.async
	} else {
		f = false
	}
	if(b.timeout != undefined) {
		g = b.timeout
	} else {
		g = 10000
	}
	if(b.data == '') {
		c = b.data
	} else {
		c = JSON.stringify(b.data)
	}
	if(b.header == '') {
		d = b.header
	} else {
		d = JSON.stringify(b.header)
	}
	var h;
	if(tmpTag == true) {
		h = 'https://' + urldomain1 + '/interfaces/wxTransferPort.do'
	} else {
		h = 'http://' + urldomain1 + '/interfaces/wxTransferPort.do'
	}
	c = c.replace(/{/g, "dhzkh");
	c = c.replace(/}/g, "dhykh");
	if(b.dataType == undefined) {
		b.dataType = 'json'
	}
	var i = {
		requestUrl: b.url,
		datas: c,
		heads: d
	};
	$.ajax({
		url: h,
		data: i,
		xhrFields: {
			withCredentials: true
		},
		crossDomain: true,
		dataType: 'jsonp',
		jsonp: 'callback',
		type: 'get',
		async: f,
		timeout: g,
		success: function(a) {
			b.success(a)
		},
		error: function(e) {
			b.fail(e)
		}
	});
	// GetCurrentLocatio('1')
};
//sha1加密
lightAppJssdk.encrypt = (function() {

	function encrypt(option) {
		var shuzu = [];
		var obj = JSON.parse(option.jsonStr);
		for(var p in obj) {
			if(p != 'sign') {
				shuzu.push(p + obj[p])
			}
		}
		var ss = "SY6C694F21A37240BCA461BB75674CA4appid20180706000101" + shuzu.sort().join('')
		var sss = hex_sha1(ss);
		option.success(sss);
	};

	function decrypt(option) {
		var jsonStr = option.jsonStr.myReplace("\r", "").myReplace("\n", "").myReplace("\t", "").myReplace("\"", "");
		var a = CryptoJS.enc.Utf8.parse("woaishenyuegjj88"),
			c = CryptoJS.enc.Utf8.parse("ShineYueAppDDing");
		var results = CryptoJS.AES.decrypt(jsonStr, a, {
			iv: c,
			mode: CryptoJS.mode.CBC,
			padding: CryptoJS.pad.Pkcs7
		}).toString(CryptoJS.enc.Utf8);
		option.success(results);
	};
	return {
		encrypt: encrypt,
		decrypt: decrypt

	}
})();
lightAppJssdk.dataUtil = (function() {
	//保存数据
	function setItem(option) {
		var i = 0;
		var keys = option.key;
		localStorage.setItem(option.key, option.value);
		setTimeout(function() {
			if(i == 0) {
				option.success('保存成功');
			}
		}, 1500);

	};

	//读取数据
	function getItem(option) {
		var data = localStorage.getItem(option.key);
		option.success(localStorage.getItem(option.key));

	};

	//删除数据
	function removeItem(option) {
		var data = localStorage.getItem(option.key);
		if(data != undefined) {
			localStorage.removeItem(option.key);
			setTimeout(function() {
				option.success('删除成功');
			}, 1500);
		} else {
			option.success('key为空');
		}

	};

	return {
		setItem: setItem,
		getItem: getItem,
		removeItem: removeItem
	}
})();
lightAppJssdk.request = (function() {
	function request(b) {
		var c;
		var d;
		var f;
		var g;
		if(b.async != undefined) {
			f = b.async
		} else {
			f = false
		}
		if(b.timeout != undefined) {
			g = b.timeout
		} else {
			g = 10000
		}
		if(b.data == '') {
			c = b.data
		} else {
			c = JSON.stringify(b.data)
		}
		if(b.header == '') {
			d = b.header
		} else {
			d = JSON.stringify(b.header)
		}
		var h;
		if(tmpTag == true) {
			h = 'https://' + urldomain1 + '/interfaces/wxTransferPort.do'
		} else {
			h = 'http://' + urldomain1 + '/interfaces/wxTransferPort.do'
		}
		c = c.replace(/{/g, "dhzkh");
		c = c.replace(/}/g, "dhykh");
		if(b.dataType == undefined) {
			b.dataType = 'json'
		}
		var i = {
			requestUrl: b.url,
			datas: c,
			heads: d
		};
		$.ajax({
			url: h,
			data: i,
			xhrFields: {
				withCredentials: true
			},
			crossDomain: true,
			dataType: 'jsonp',
			jsonp: 'callback',
			type: 'get',
			async: f,
			timeout: g,
			success: function(a) {
				b.success(a)
			},
			error: function(e) {
				b.fail(e)
			}
		});
		// GetCurrentLocatio('1')
	};
	return {
		request: request
	}
})();
// GetCurrentLocation('');

function GetCurrentLocation(h) {};

function GetCurrentLocatio(d) {};

function IEVersion() {
	var a = navigator.userAgent;
	var b = a.indexOf("compatible") > -1 && a.indexOf("MSIE") > -1;
	var c = a.indexOf("Edge") > -1 && !b;
	var d = a.indexOf('Trident') > -1 && a.indexOf("rv:11.0") > -1;
	if(b) {
		var e = new RegExp("MSIE (\\d+\\.\\d+);");
		e.test(a);
		var f = parseFloat(RegExp["$1"]);
		if(f == 7) {
			return 7
		} else if(f == 8) {
			return 8
		} else if(f == 9) {
			return 9
		} else if(f == 10) {
			return 10
		} else {
			return 6
		}
	} else if(c) {
		return 'edge'
	} else if(d) {
		return 11
	} else {
		return -1
	}
};
lightAppJssdk.notification = (function() {

	function alert(option) {
		alert(options.message);
	};

	function confirm(option) {
		alert(options.message);
	};

	function prompt(option) {

	};

	function actionSheet(option) {

	};

	function showPreloader(option) {

	};

	function hidePreloader(option) {

	};

	function toast(option) {

	};
	function showAuthAlert(option) {
	
	};

	return {
		alert: alert,
		confirm: confirm,
		prompt: prompt,
		actionSheet: actionSheet,
		showPreloader: showPreloader,
		hidePreloader: hidePreloader,
		toast: toast,
		showAuthAlert:showAuthAlert,
	}

})();
//获取用户信息
lightAppJssdk.user = (function() {
	//获得用户信息
	function getTicket(option) {
		var Request = GetRequest();
		if(location.href.indexOf("token=") == -1) {
			if(location.href.indexOf("ticket=") == -1) {
				//链接后无票据
				var token = localStorage.getItem("tokenjssdk");
				if(token == null) {
					//					alert('container：wx;result:未登录');
					option.success("未登录");
				} else {
					token = decodeURI(token);

					var data = {
						token: token
					}
					var requesturl;
					if(tmpTag == true) {
						requesturl = "https://www.jszwfw.gov-cn-blocked.au/jmopen/interfaces/UserAuth/getTicket.do";
					} else {
						requesturl = "http://www.jszwfw.gov-cn-blocked.au/jmopen/interfaces/UserAuth/getTicket.do";
					}
					lightAppJssdk.request.request({
						url: requesturl,
						data: data,
						header: '',
						type: 'post', //HTTP请求类型
						async: false, //同步
						timeout: 10000, //超时时间设置为10秒；
						success: function(data) {
							//							alert('container：wx;result:' + JSON.stringify(data));
							option.success(JSON.stringify(data));
						},
						error: function(e) {

						}
					});
				}
			} else {
				var tickets = location.href.split("ticket=")[1].split("&")[0];
				var ticket = {
					result: "true",
					ticket: tickets
				}
				//				alert('container：wx;result:' + JSON.stringify(ticket));
				option.success(JSON.stringify(ticket));
			}

		} else {
			var token = location.href.split("token=")[1].split("&")[0];
			token = token.split("#")[0];

			localStorage.setItem("tokenjssdk", token);

			var data = {
				token: token
			}
			var requesturl;
			if(tmpTag == true) {
				requesturl = "https://www.jszwfw.gov-cn-blocked.au/jmopen/interfaces/UserAuth/getTicket.do";
			} else {
				requesturl = "http://www.jszwfw.gov-cn-blocked.au/jmopen/interfaces/UserAuth/getTicket.do";
			}
			try {
				lightAppJssdk.request.request({
					url: requesturl,
					data: data,
					header: '',
					type: 'post', //HTTP请求类型
					async: false, //同步
					timeout: 10000, //超时时间设置为10秒；
					success: function(data) {
						option.success(JSON.stringify(data));
					},
					error: function(e) {}
				});
			} catch(e) {}

		}

	};
	//登录
	function loginapp(option) {
		//		alert('container：wx;action:loginapp');
		if(location.href.indexOf("token=") == -1) {
			var token = window.localStorage.token;

			if(token == "" || typeof(token) == "undefined") { //未登录
				if(tmpTag == true) {
					window.location.href = "https://www.jszwfw.gov-cn-blocked.au/jmopen/jssdk/wechatlogin/login.html?location=" + window.location;

				} else {
					window.location.href = "http://www.jszwfw.gov-cn-blocked.au/jmopen/jssdk/wechatlogin/login.html?location=" + window.location;

				}

			} else {
				option.success("已登录");
			}
		} else {
			option.success("已登录");
		}

	};

	//注销
	function logout(option) {
		window.localStorage.token = "";
		option.success("注销成功");
	};
	return {
		getTicket: getTicket,
		loginapp: loginapp,
		logout: logout

	}

})();

//页面加载
lightAppJssdk.navigation = (function() {
	//页面加载
	function show(option) {
		window.location.href = option.url;
	};
	//页面加载
	function hide(option) {
		window.location.href = option.url;
	};

	//页面加载
	function close(option) {
		option.success("未扩展组件");
	};
	return {
		show: show,
		hide: hide,
		close: close
	}
})();
var data;
//位置数据
lightAppJssdk.map = (function() {
	//获取定位
	function getLocation(option) {
		var geolocation = new BMap.Geolocation();
		geolocation.getCurrentPosition(function(r) {
			if(this.getStatus() == BMAP_STATUS_SUCCESS) {

				// 创建地址解析器实例     
				var myGeo = new BMap.Geocoder();
				// 根据坐标得到地址描述    
				myGeo.getLocation(new BMap.Point(r.point.lng, r.point.lat), function(result) {
					if(result) {
						data = {
							cityName: r.address.city,
							region: result.addressComponents.district,
							detailAddress: result.address,
							longitude: r.point.lng,
							latitude: r.point.lat,
							province: r.address.province
						}
					} else {
						data = {
							cityName: r.address.city,
							region: "",
							detailAddress: "",
							longitude: r.point.lng,
							latitude: r.point.lat,
							province: r.address.province
						}
					}
					option.success(data);
				});
			} else {
				data = {
					result: "fail"
				}
				option.success(data);
			}

		});
	};
	return {
		getLocation: getLocation
	}
})();
/**
 * 获取url中"?"符后的字串
 */
function GetRequest() {
	var url = window.location.search;
	var theRequest = new Object();
	if(url.indexOf("?") != -1) {
		var str = url.substr(1);
		strs = str.split("&");
		for(var i = 0; i < strs.length; i++) {
			theRequest[strs[i].split("=")[0]] = (strs[i].split("=")[1]);
		}
	}
	return theRequest;
}