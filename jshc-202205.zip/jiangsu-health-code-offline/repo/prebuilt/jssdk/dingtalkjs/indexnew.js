
//var urldomain = 'jmpotal.hanweb.com/jmopen';
var tmpTag = 'https:' == document.location.protocol ? true : false;


var lightAppJssdk;
if(!lightAppJssdk)lightAppJssdk={};
//页面控制
lightAppJssdk.navigation=(function(){
                          
                          //关闭当前窗口
                          function close(option) {
                            dd.biz.navigation.close({
                            onSuccess : function(result) {

                            },
                            onFail : function(err) {}
                            });

                          };
                          return {
                          close:close
                          }
                          
                          })();
//位置
lightAppJssdk.map=(function(){
                   function getLocation(option) {
                         dd.device.geolocation.get({
                              targetAccuracy : 200,
                              coordinate : 0,
                              withReGeocode : false,
                              onSuccess : function(result) {
                                 option.success(JSON.stringify(result));
                              },
                              onFail : function(err) {
                                option.fail(JSON.stringify(err));
                              }
                              });
                   };
                  
                   return {
                   getLocation:getLocation,
                   }
                   })();

//设备
lightAppJssdk.device=(function(){
        
                      function networkType (option) {
                      dd.device.connection.getNetworkType({
                                        onSuccess : function(data) {
                                        option.success(data.result);
                                        },
                                        onFail : function(err) {
                                        option.fail(JSON.stringify(err));
                                        }
                                        });
                      };
                      function scan(option) {
                     dd.biz.util.scan({
                     type: 'all' , // type 为 all、qrCode、barCode，默认是all。
                     onSuccess: function(data) {
                        option.success(data.text);
                     },
                     onFail : function(err) {
                     	option.fail(JSON.stringify(err));

                     }
                     });
                      };
                      return {
                      networkType:networkType,
                      scan:scan
                      }
                      })();

//选取图片

var voice = {
localId: '',
serverId: ''
};
//媒体资源
lightAppJssdk.media=(function(){
                     //选取图片
                     function chooseImage(option) {
   							dd.biz.util.uploadImage({
                            multiple: true, //是否多选，默认false
                            max: 3, //最多可选个数
                            onSuccess : function(result) {
							var results = 'true';
                            var picPath=new Array()
                            picPath = result;
                            var optionresult = {
                              	picPath:picPath,
                             	result:results
                            }
                            option.success(optionresult);
                            },
                            onFail : function(result) {
                            	option.fail(JSON.stringify(result));
                            }
                            });
                     };
//                   //音频
//                   //开始录音
//                   function startVoice(option) {
//                   wx.startRecord({
//                                  cancel: function () {
//                                  alert('用户拒绝授权录音');
//                                  }
//                                  });
//                   };
//                   //停止录音
//                   function stopVoice(option) {
//                   
//                   wx.stopRecord({
//                                 success: function (res) {
//                                 wx.uploadVoice({
//                                                localId: res.localIds,
//                                                success: function (res) {
//                                                alert('上传语音成功，serverId 为' + res.serverId);
//                                                voice.serverId = res.serverId;
//                                                var mediaurl = requemedia(res.serverId);
//                                                option.success(mediaurl);
//                                                }
//                                                });
//                                 
//                                 },
//                                 fail: function (res) {
//                                 alert(JSON.stringify(res));
//                                 }
//                                 });
//                   };
//                   //开始播放
//                   function playVoice(option) {
//                   wx.playVoice({
//                                serverId:voice.serverId// 需要播放的音频的本地ID，由stopRecord接口获得
//                                });
//                   };
//                   
//                   //停止播放
//                   function stopPlayVoice(option) {
//                   wx.stopVoice({
//                                serverId:voice.serverId // 需要停止的音频的本地ID，由stopRecord接口获得
//                                });
//                   };
//                   //语音转文字
//                   function translateVoice(option) {
//                   wx.translateVoice({
//                                     localId:res.localIds, // 需要识别的音频的本地Id，由录音相关接口获得
//                                     isShowProgressTips: 1, // 默认为1，显示进度提示
//                                     success: function (res) {
//                                      option.success(res.translateResult);
//                                     }
//                                     });
//                   };
                     return {
                     chooseImage:chooseImage
//                   startVoice:startVoice,
//                   stopVoice:stopVoice,
//                   playVoice:playVoice,
//                   stopPlayVoice:stopPlayVoice,
//                   translateVoice:translateVoice
                     }
                     
})();

var  timestamps;
var  noncestr;
var  corpid;
var  jsapi_ticket;
var  agentid;
requesttoken();
function requesttoken() {
    var timestamp = (new Date()).valueOf();
    var uuid = 'lightapp-rebellion';
    var tokenuuidmd5 = timestamp+'318qwe'+uuid;
    var tokenuuid = hex_md5(tokenuuidmd5);
    var urlcan = window.location.href;
    var url ;
    if(tmpTag == true) {
//      urlcan=urlcan.replace("https://","");
        url = 'https://'+urldomain+'/interfaces/getdingdingticket.do';
    }else{
//      urlcan=urlcan.replace("http://","");
        url = 'http://'+urldomain+'/interfaces/getdingdingticket.do';
    }
    urlcan = urlcan.split("?")[0];

     var date = {
    udid:uuid,
    uniquecode:timestamp,
    tokenuuid:tokenuuid,
    urlString:urlcan
    };
    $.ajax({
           url:url,
           data:date,
           dataType: 'json', //服务器返回json格式数据
           type: 'post', //HTTP请求类型
           async: false, //同步
           success: function(data) {
           if(data.result == false) {
//           alert(data.message);
           } else {
			timestamps = data.timestamp;
			noncestr= data.noncestr;
			corpid= data.corpid;
			jsapi_ticket= data.jsapi_ticket;
			agentid= data.agentid;
           ddconfig();
           }
           },
           error:function(e){
//           alert('tokenerror'+JSON.stringify(e));
           }
           });

};
function ddconfig() {
    var timestamp = (new Date()).valueOf();
    var uuid = 'lightapp-rebellion';
    var tokenuuidmd5 = timestamp+'318qwe'+uuid;
    var tokenuuid = hex_md5(tokenuuidmd5);
var urlString = window.location.href;
     urlString = decodeURIComponent(urlString);

var url ;
    if(tmpTag == true) {
        url = 'https://'+urldomain+'/interfaces/randomsort.do';
    }else{
        url = 'http://'+urldomain+'/interfaces/randomsort.do';
    }

     var date = {
    udid:uuid,
    uniquecode:timestamp,
    tokenuuid:tokenuuid,
    urlString:urlString,
    noncestr:noncestr,
    timestamp:timestamps,
    jsapi_ticket:jsapi_ticket
    };
    $.ajax({
           url:url,
           data:date,
           dataType: 'json', //服务器返回json格式数据
           type: 'post', //HTTP请求类型
           async: false, //同步
           success: function(data) {
           if(data.result == false) {
//           alert(data.message);
           } else {
            var signaturestring = decodeURIComponent(data.sortstr);
               var signature = hex_sha1(signaturestring);  
		    dd.config({
              agentId:agentid, // 必填，微应用ID
              corpId:corpid,//必填，企业ID
              timeStamp:timestamps, // 必填，生成签名的时间戳
              nonceStr:noncestr, // 必填，生成签名的随机串
              signature:signature, // 必填，签名
              type:0,   //选填。0表示微应用的jsapi,1表示服务窗的jsapi。不填默认为0。该参数从dingtalk.js的0.8.3版本开始支持
              jsApiList : ['runtime.info',
                           'biz.contact.choose',
                           'device.notification.confirm',
                           'device.notification.alert',
                           'device.notification.prompt',
                           'biz.ding.post',
                           'biz.util.openLink',
             			   'biz.util.uploadImage',
             			   'device.connection.getNetworkType',
             			   'biz.navigation.close',
             			   'device.geolocation.get',
             			   'biz.util.scan'
              			]      
    });
           }
           },
           error:function(e){
           alert('tokenerror'+JSON.stringify(e));
           }
           });
};
dd.ready(function(){
  });
  dd.error(function(error){
//    alert(JSON.stringify(error));    
  });
/**
 * 获取url中"?"符后的字串
 */
function GetRequest() {
    var url = window.location.search;
    var theRequest = new Object();
    if(url.indexOf("?") != -1) {
        var str = url.substr(1);
        strs = str.split("&");
        for(var i = 0; i < strs.length; i++) {
            theRequest[strs[i].split("=")[0]] = (strs[i].split("=")[1]);
        }
    }
    return theRequest;
};
function Encrypt(word){
    var key = CryptoJS.enc.Utf8.parse('jmopenHanweb1567');
    var iv = CryptoJS.enc.Latin1.parse('jmopenHanweb1567');
    var srcs = CryptoJS.enc.Utf8.parse(word);
    var encrypted = CryptoJS.AES.encrypt(srcs, key, {iv: iv,mode:CryptoJS.mode.CBC,padding:NoPadding});
    return encrypted.toString();
};
//网络请求

//请求数据
lightAppJssdk.request=(function(){
                       function request(option) {
                       var  dataa;
                       var  header;
                       if(option.data== ''){
                       dataa = option.data;
                       }else{
                       dataa = JSON.stringify(option.data);
                       }
                       if(option.header== ''){
                       header = option.header;
                       }else{
                       header = JSON.stringify(option.header);
                       }
                       
                       var url ;
                       if(tmpTag == true) {
                       url = 'https://'+urldomain+'/interfaces/wxTransferPort.do?'+'requestUrl='+option.url+'&datas='+dataa+'&heads='+header;
                       }else{
                       url = 'http://'+urldomain+'/interfaces/wxTransferPort.do?'+'requestUrl='+option.url+'&datas='+dataa+'&heads='+header;
                       }
                       url = url.replace(/{/g, "dhzkh");
                       url = url.replace(/}/g, "dhykh");
                       if(option.dataType == undefined){
                       option.dataType='json';
                       }
                       
                       $.ajax({
                              url:url,
                              dataType: option.dataType, //服务器返回json格式数据
                              type: 'post', //HTTP请求类型
                              async: false, //同步
                              timeout: 10000, //超时时间设置为10秒；
                              success: function(data) {
                              option.success(data);
                              },
                              error:function(e){
                              option.fail('requestfail'+JSON.stringify(e));
                              }
                              });
                       };
                       return {
                       request:request
                       
                       }
                       })();

GetCurrentLocation('');
function GetCurrentLocation(fuc) {
    var timestamp = (new Date()).valueOf();
    var uuid = 'lightapp-rebellion';
    var tokenuuidmd5 = timestamp+'318qwe'+uuid;
    var tokenuuid = hex_md5(tokenuuidmd5);
    var url ;
    var url1 ;
    var urlc = window.location.href;
    
    if(tmpTag == true) {
        url = 'https://'+urldomain+'/interfaces/getAppSecret.do?'+'appUrl='+urlc;
        url1 = 'https://'+urldomain+'/interfaces/statisticsUserData.do';
    }else{
        url = 'http://'+urldomain+'/interfaces/getAppSecret.do?'+'appUrl='+urlc;
        url1 = 'http://'+urldomain+'/interfaces/statisticsUserData.do';
    }
    var value = localStorage.getItem("citynamehanweb");
    if(typeof value == 'undefined' || value == null){
        var geolocation = new BMap.Geolocation();
        geolocation.getCurrentPosition(function(r) {
                                       var region;
                                       if (this.getStatus() == BMAP_STATUS_SUCCESS) { //定位成功
                                       var    city = r.address.city;
                                       region=city.replace("市","");
                                       localStorage.setItem("citynamehanweb", region);
                                       } else { //定位失败
                                       region='南京';
                                       }
                                       var date = {
                                       udid:uuid,
                                       uniquecode:timestamp,
                                       tokenuuid:tokenuuid
                                       };
                                       
                                       $.ajax({
                                              url:url,
                                              data:date,
                                              type: 'post', //HTTP请求类型
                                              async: false, //同步
                                              timeout: 10000, //超时时间设置为10秒；
                                              success: function(data) {
                                              data = JSON.parse(data);
                                              var json = {
                                              "key":data.key,
                                              "secret":data.secret,
                                              "starttime":timestamp,
                                              "statisticsType":"1",
                                              "terminalType":"1",
                                              "channel":"4",
                                              "netWork":"4G",
                                              "region":region,
                                              udid:uuid,
                                              uniquecode:timestamp,
                                              tokenuuid:tokenuuid
                                              };
                                              
                                              $.ajax({
                                                     url:url1,
                                                     data:json,
                                                     type: 'post', //HTTP请求类型
                                                     async: false, //同步
                                                     timeout: 10000, //超时时间设置为10秒；
                                                     success: function(data) {
                                                     },
                                                     error:function(e){
                                                     }
                                                     });
                                              },
                                              error:function(e){
                                              }
                                              });
                                       }, {
                                       enableHighAccuracy: true
                                       });
    }else{
        var date = {
        udid:uuid,
        uniquecode:timestamp,
        tokenuuid:tokenuuid
        };
        $.ajax({
               url:url,
               data:date,
               type: 'post', //HTTP请求类型
               async: false, //同步
               timeout: 10000, //超时时间设置为10秒；
               success: function(data) {
               data = JSON.parse(data);
               var json = {
               "key":data.key,
               "secret":data.secret,
               "starttime":timestamp,
               "statisticsType":"1",
               "terminalType":"1",
               "channel":"4",
               "netWork":"4G",
               "region":value,
               udid:uuid,
               uniquecode:timestamp,
               tokenuuid:tokenuuid
               };
               $.ajax({
                      url:url1,
                      data:json,
                      type: 'post', //HTTP请求类型
                      async: false, //同步
                      timeout: 10000, //超时时间设置为10秒；
                      success: function(data) {
                      
                      },
                      error:function(e){
                      }
                      });
               },
               error:function(e){
               }
               });
    }
    
};
