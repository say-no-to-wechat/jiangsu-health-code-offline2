var urldomain = "www.jszwfw.gov-cn-blocked.au/jmopen",

	lightAppJssdk;
lightAppJssdk || (lightAppJssdk = {});
var Request = GetRequest();
if(Request.token != undefined) {
	var tokens = location.href.split("token=")[1].split("&")[0];
	localStorage.setItem("tokenjssdk", tokens);
}

var timestamp = (new Date).valueOf(),
	uuid = "lightapp-rebellion",
	tokenuuidmd5 = timestamp + "318qwe" + uuid,
	tokenuuid = hex_md5(tokenuuidmd5);
var tmpTag = 'https:' == document.location.protocol ? true : false;

//数据相关
lightAppJssdk.dataUtil = (function() {
	//保存数据
	function setItem(option) {
		var i = 0;
		var keys = option.key;
		localStorage.setItem(option.key, option.value);
		setTimeout(function() {
			if(i == 0) {
				option.success('保存成功');
			}
		}, 1500);

	};

	//读取数据
	function getItem(option) {
		var data = localStorage.getItem(option.key);
		option.success(localStorage.getItem(option.key));

	};

	//删除数据
	function removeItem(option) {
		var data = localStorage.getItem(option.key);
		if(data != undefined) {
			localStorage.removeItem(option.key);
			setTimeout(function() {
				option.success('删除成功');
			}, 1500);
		} else {
			option.success('key为空');
		}

	};

	return {
		setItem: setItem,
		getItem: getItem,
		removeItem: removeItem
	}
})();
//sha1加密
lightAppJssdk.encrypt = (function() {

	function encrypt(option) {
		var shuzu = [];
		var obj = JSON.parse(option.jsonStr);
		for(var p in obj) {
			if(p != 'sign') {
				shuzu.push(p + obj[p])
			}
		}
		var ss = "SY6C694F21A37240BCA461BB75674CA4appid20180706000101" + shuzu.sort().join('')
		var sss = hex_sha1(ss);
		option.success(sss);
	};

	function decrypt(option) {
		var jsonStr = option.jsonStr.myReplace("\r", "").myReplace("\n", "").myReplace("\t", "").myReplace("\"", "");
		var a = CryptoJS.enc.Utf8.parse("woaishenyuegjj88"),
			c = CryptoJS.enc.Utf8.parse("ShineYueAppDDing");
		var results = CryptoJS.AES.decrypt(jsonStr, a, {
			iv: c,
			mode: CryptoJS.mode.CBC,
			padding: CryptoJS.pad.Pkcs7
		}).toString(CryptoJS.enc.Utf8);
		option.success(results);
	};
	return {
		encrypt: encrypt,
		decrypt: decrypt

	}
})();

//获取用户信息
lightAppJssdk.user = (function() {
	//获得用户信息
	function getTicket(option) {
		var Request = GetRequest();
		if(location.href.indexOf("token=") == -1) {
			if(location.href.indexOf("ticket=") == -1) {
				//链接后无票据
				var token = localStorage.getItem("tokenjssdk");
				if(token == null) {
					option.success("未登录");
				} else {
					token = decodeURI(token);

					var data = {
						token: token
					}
					var requesturl;
					if(tmpTag == true) {
						requesturl = "https://www.jszwfw.gov-cn-blocked.au/jmopen/interfaces/UserAuth/getTicket.do";
					} else {
						requesturl = "http://www.jszwfw.gov-cn-blocked.au/jmopen/interfaces/UserAuth/getTicket.do";
					}
					lightAppJssdk.request.request({
						url: requesturl,
						data: data,
						header: '',
						type: 'post', //HTTP请求类型
						async: false, //同步
						timeout: 10000, //超时时间设置为10秒；
						success: function(data) {
							option.success(JSON.stringify(data));
						},
						error: function(e) {

						}
					});
				}
			} else {
				var tickets = location.href.split("ticket=")[1].split("&")[0];
				var ticket = {
					result: "true",
					ticket: tickets
				}
				option.success(JSON.stringify(ticket));
			}

		} else {
			var token = location.href.split("token=")[1].split("&")[0];
			localStorage.setItem("tokenjssdk", token);

			var data = {
				token: token
			}
			var requesturl;
			if(tmpTag == true) {
				requesturl = "https://www.jszwfw.gov-cn-blocked.au/jmopen/interfaces/UserAuth/getTicket.do";
			} else {
				requesturl = "http://www.jszwfw.gov-cn-blocked.au/jmopen/interfaces/UserAuth/getTicket.do";
			}
			try {
				lightAppJssdk.request.request({
					url: requesturl,
					data: data,
					header: '',
					type: 'post', //HTTP请求类型
					async: false, //同步
					timeout: 10000, //超时时间设置为10秒；
					success: function(data) {
						option.success(JSON.stringify(data));
					},
					error: function(e) {}
				});
			} catch(e) {}

		}

	};
	//登录
	function loginapp(option) {
		option.success("此端无法执行登录");
	};

	//注销
	function logout(option) {
		window.localStorage.token = "";
		option.success("注销成功");
	};
	return {
		getTicket: getTicket,
		loginapp: loginapp,
		logout: logout

	}

})();

//人脸识别
lightAppJssdk.face = (function() {

	let SFoption;

	function face(option) {
		SFoption = option;
		my.postMessage({
			name: "扫脸"
		});
	};

	// 返回结果
	my.onMessage = function(e) {
		let data;
		if(e.res == '认证通过') {
			data = {
				"result": "true",
				"msg": "成功"
			}
		} else if(e.res == '用户取消') {
			data = {
				"result": "false",
				"msg": "用户取消"
			}
		} else {
			data = {
				"result": "false",
				"msg": "认证失败"
			}
		}
		SFoption.success(JSON.stringify(data));
	}

	//活体检测
	function liveness(option) {
		option.fail("不支持该组件");
	};

	return {
		face: face,
		liveness: liveness
	}
})();

//提示信息
// 弹窗
lightAppJssdk.notification = (function() {

	function alert(option) {
		AlipayJSBridge.call('alert', {
			title: option.title,
			message: option.message,
			button: option.buttonName
		}, function(e) {
			option.success("点击了按钮");
		});

	};

	function confirm(option) {
		AlipayJSBridge.call('confirm', {
			title: option.title,
			message: option.message,
			okButton: option.buttonLabels[0],
			cancelButton: option.buttonLabels[1]
		}, function(e) {
			var buttonIndex;
			if(e.ok) {
				buttonIndex = 1;
			} else {
				buttonIndex = 0;

			}
			var dic = {
				buttonIndex: buttonIndex
			}
			option.success(JSON.stringify(dic));
		});

	};

	function prompt(option) {
		AlipayJSBridge.call('prompt', {
			title: option.title,
			message: option.message,
			placeholder: '',
			okButton: option.buttonLabels[0],
			cancelButton: option.buttonLabels[1]
		}, function(result) {
			var buttonIndex;
			if(result.ok) {
				buttonIndex = 1;
			} else {
				buttonIndex = 0;

			}
			var dic = {
				buttonIndex: buttonIndex,
				value: result.inputValue
			}
			option.success(JSON.stringify(dic));
		});
	};

	function actionSheet(option) {
		AlipayJSBridge.call('actionSheet', {
			'title': option.title,
			'btns': option.otherButtons,
			'cancelBtn': option.cancelButton
		}, function(data) {
			var dic = {
				buttonIndex: data.index,

			}
			option.success(JSON.stringify(dic));
		});

	};
	//
	function showPreloader(option) {
		AlipayJSBridge.call('showLoading', {
			text: option.text,
		});
		option.success("success");
	};

	function hidePreloader(option) {

		AlipayJSBridge.call('hideLoading');
		option.success("success");

	};

	function toast(option) {
		AlipayJSBridge.call('toast', {
			content: option.text,
			duration: 2000
		}, function() {
			option.success("success");
		});

	};
	
	function showAuthAlert(option) {
		AlipayJSBridge.call('showAuthAlert', {
			title: option.title,
			message: option.message,
			okButton: option.buttonLabels[0],
			cancelButton: option.buttonLabels[1]
		}, function(data) {
			var dic = {
				buttonIndex: data.index,
	
			}
			option.success(JSON.stringify(dic));
		});
	
	};

	return {
		alert: alert,
		confirm: confirm,
		prompt: prompt,
		actionSheet: actionSheet,
		showPreloader: showPreloader,
		hidePreloader: hidePreloader,
		toast: toast,
		showAuthAlert: showAuthAlert,
	}

})();

function requemedia(b) {
	$.ajax({
		url: tmpTag ? "https://" + urldomain + "/interfaces/getmediaurl.do" : "http://" + urldomain + "/interfaces/getmediaurl.do",
		data: {
			dataUrl: b.dataURL,
			udid: uuid,
			uniquecode: timestamp,
			tokenuuid: tokenuuid
		},
		dataType: "json",
		type: "post",
		async: !1,
		timeout: 1E4,
		success: function(a) {
			"false" == a.result ? alert(a.msg) : b.success(a.mediaurl)
		},
		error: function(b) {}
	})
}
lightAppJssdk.map = function() {
	return {
		getLocation: function(b) {
			AlipayJSBridge.call("getLocation", function(a) {
				a.error ? b.fail(a.errorMessage) : b.success({
					cityName: a.city,
					detailAddress: a.streetNumber,
					region: a.adcode,
					longitude: a.longitude,
					latitude: a.latitude
				})
			})
		}
	}
}();

function Decrypt(b) {
	var a = CryptoJS.enc.Utf8.parse("jmopenHanweb1567"),
		c = CryptoJS.enc.Latin1.parse("jmopenHanweb1567");
	return CryptoJS.AES.decrypt(b, a, {
		iv: c,
		padding: CryptoJS.pad.NoPadding
	}).toString(CryptoJS.enc.Utf8)
}

function Trim(b, a) {
	b = b.replace(/(^\s+)|(\s+$)/g, "");
	"g" == a.toLowerCase() && (b = b.replace(/\s/g, ""));
	return b
}
lightAppJssdk.device = function() {
	return {
		networkType: function(b) {
			AlipayJSBridge.call("getNetworkType", function(a) {
				b.success(a.networkType)
			})
		},
		scan: function(b) {
			AlipayJSBridge.call("scan", {
				type: "bar"
			}, function(a) {
				b.success(a)
			})
		}
	}
}();
lightAppJssdk.navigation = function() {
	return {
		close: function(b) {
			AlipayJSBridge.call("closeWebview")
		},
		show: function(option) {
			AlipayJSBridge.call('pushWindow', {
				url: option.url,
				param: {
					readTitle: true,
					showOptionMenu: false
				}
			})
		},
		hide: function(option) {
			AlipayJSBridge.call('pushWindow', {
				url: option.url,
				param: {
					readTitle: false,
					showOptionMenu: false
				}
			})
		}
	}
}();
var images = {
	picPath: [],
	result: "true"
};
lightAppJssdk.media = function() {
	return {
		chooseImage: function(b) {
			AlipayJSBridge.call("photo", {
				dataType: "dataURL",
				imageFormat: "jpg",
				quality: 75,
				maxWidth: 500,
				maxHeight: 500,
				allowEdit: !0
			}, function(a) {
				if(a.dataURL != undefined) {
					requemedia({
						dataURL: a.dataURL,
						success: function(a) {
							images.picPath[0] = a;
							b.success(images)
						}
					})
				}
			})
		},
		chooseVideoAndPic: function(b) {
			AlipayJSBridge.call("photo", {
				dataType: "dataURL",
				imageFormat: "jpg",
				quality: 75,
				maxWidth: 500,
				maxHeight: 500,
				allowEdit: !0
			}, function(a) {
				if(a.dataURL != undefined) {
					requemedia({
						dataURL: a.dataURL,
						success: function(a) {
							images.picPath[0] = a;
							b.success(images)
						}
					})
				}
			})
		}
	}
}();
var tokenString;

function getUserInfo(b) {
	var requesturl;
	if(tmpTag == true) {
		requesturl = "https://" + urldomain + "/interfaces/ticketValidation.do";
	} else {
		requesturl = "http://" + urldomain + "/interfaces/ticketValidation.do";
	}

	var a = {},
		a = GetRequest(),
		c = a.ticket,
		a = cookieUtil.get(c);
	null != a ? (tokenString = a, getUserInfoResult(b)) : $.ajax({
		url: requesturl,
		data: {
			st: c,
			udid: uuid,
			uniquecode: timestamp,
			tokenuuid: tokenuuid
		},
		dataType: "json",
		type: "post",
		async: !1,
		timeout: 1E4,
		success: function(a) {
			tokenString = JSON.parse(a).token;
			cookieUtil.set(c, tokenString, setCookieDatecustom(2));
			getUserInfoResult(b)
		},
		error: function(a) {
			b.fail(a)
		}
	})
}

function getUserInfoResult(b) {
	var requesturl;
	if(tmpTag == true) {
		requesturl = "https://" + urldomain + "/interfaces/getUserInfo.do";
	} else {
		requesturl = "http://" + urldomain + "/interfaces/getUserInfo.do";
	}
	$.ajax({
		url: requesturl,
		data: {
			token: tokenString,
			udid: uuid,
			uniquecode: timestamp,
			tokenuuid: tokenuuid
		},
		dataType: "",
		type: "post",
		async: !1,
		timeout: 1E4,
		success: function(a) {
			a = Decrypt(Trim(a, "g"));
			b.success(a)
		},
		error: function(a) {
			b.fail(a)
		}
	})
}

function getUserTicket(b) {
	var a;
	a = GetRequest();
	b.success(a.ticket)
}

function GetRequest() {
	var b = window.location.search,
		a = {};
	if(-1 != b.indexOf("?"))
		for(strs = b.substr(1).split("&"), b = 0; b < strs.length; b++) a[strs[b].split("=")[0]] = strs[b].split("=")[1];
	return a
}
var cookieUtil = {
	set: function(b, a, c, d, f, e) {
		b = encodeURIComponent(b) + "=" + encodeURIComponent(a);
		c instanceof Date && (b += ";expires=" + c.toGMTString());
		d && (b += ";path=" + d);
		f && (b += ";domain=" + f);
		e && (b += ";secure");
		document.cookie = b
	},
	get: function(b) {
		b = encodeURIComponent(b) + "=";
		var a = document.cookie.indexOf(b),
			c = null; - 1 < a && (c = document.cookie.indexOf(";", a), -1 == c && (c = document.cookie.length), c = decodeURIComponent(document.cookie.substring(a + b.length, c)));
		return c
	},
	unset: function(b, a, c, d) {
		this.set(b, "", new Date(0),
			c, a)
	}
};

function setCookieDatecustom(b) {
	var a;
	a = new Date;
	a.setDate(a.getTime() + 6E4 * b);
	return a
}

//网络请求
lightAppJssdk.request = (function() {
	function request(option) {
		var dataa;
		var header = '';
		var async;
		var timeout;
		if(option.async != undefined) {
			async = option.async;
		} else {
			async = false;
		}
		if(option.timeout != undefined) {
			timeout = option.timeout;
		} else {
			timeout = 10000;
		}
		if(option.data == '') {
			dataa = option.data;
		} else {
			dataa = JSON.stringify(option.data);
			dataa = dataa.replace(/\%/g, '%25').replace(/\#/g, '%23').replace(/\+/g, '%2B').replace(/\//g, '%2F').replace(/\?/g, '%3F').replace(/\&/g, '%26').replace(/\=/g, '%3D')

		}
		if(option.header == '' || option.header == undefined) {
			header = option.header;
		} else {
			header = JSON.stringify(option.header);
		}
		var url;
		if(tmpTag == true) {
			url = 'https://' + urldomain + '/interfaces/wxTransferPort.do';
		} else {
			url = 'http://' + urldomain + '/interfaces/wxTransferPort.do';
		}
		dataa = dataa.replace(/{/g, "dhzkh");
		dataa = dataa.replace(/}/g, "dhykh");
		if(header != '' && header != undefined) {
			header = header.replace(/{/g, "dhzkh");
			header = header.replace(/}/g, "dhykh");
		}
		if(option.dataType == undefined) {
			option.dataType = 'jsonp';
		}
		var dat = {
			requestUrl: option.url,
			datas: dataa,
			heads: header
		};
		$.ajax({
			url: url,
			data: dat,
			xhrFields: {
				withCredentials: true
			},
			crossDomain: true,
			dataType: option.dataType,
			jsonp: 'callback',
			//                              dataType: option.dataType, //服务器返回json格式数据
			type: 'get', //HTTP请求类型
			async: async, //同步
			timeout: timeout, //超时时间设置为10秒；
			success: function(data) {
				option.success(data);
			},
			error: function(e) {
				option.fail(e);
			}
		});
	};
	return {
		request: request
	}
})();

function GetCurrentLocation(b) {
	var a = (new Date).valueOf(),
		c = hex_md5(a + "318qwelightapp-rebellion"),
		d = localStorage.getItem("citynamehanweb");
	"undefined" == typeof d || null == d ? (new BMap.Geolocation).getCurrentPosition(function(b) {
		var e;
		this.getStatus() == BMAP_STATUS_SUCCESS ? (e = b.address.city.replace("\u5e02", ""), localStorage.setItem("citynamehanweb", e)) : e = "\u5357\u4eac";
		var requesturl;
		var requesturl1;

		if(tmpTag == true) {
			requesturl = "https://" + urldomain + "/interfaces/getAppSecret.do?appUrl=" + window.location.href;
			requesturl1 = "https://" + urldomain + "/interfaces/statisticsUserData.do";
		} else {
			requesturl = "http://" + urldomain + "/interfaces/getAppSecret.do?appUrl=" + window.location.href;
			requesturl1 = "http://" + urldomain + "/interfaces/statisticsUserData.do";
		}
		$.ajax({
			url: requesturl,
			data: {
				udid: "lightapp-rebellion",
				uniquecode: a,
				tokenuuid: c
			},
			type: "post",
			async: !1,
			timeout: 1E4,
			success: function(a) {
				a = JSON.parse(a);
				var b = Date.parse(new Date);
				$.ajax({
					url: requesturl1,
					data: {
						key: a.key,
						secret: a.secret,
						starttime: b,
						statisticsType: "1",
						terminalType: "1",
						channel: "1",
						netWork: "4G",
						region: e,
						udid: "lightapp-rebellion",
						uniquecode: b,
						tokenuuid: c
					},
					type: "post",
					async: !1,
					timeout: 1E4,
					success: function(a) {},
					error: function(a) {}
				})
			},
			error: function(a) {}
		})
	}, {
		enableHighAccuracy: !0
	}) : $.ajax({
		url: tmpTag == true ? "https://" + urldomain +
			"/interfaces/getAppSecret.do?appUrl=" + window.location.href : "http://" + urldomain +
			"/interfaces/getAppSecret.do?appUrl=" + window.location.href,
		data: {
			udid: "lightapp-rebellion",
			uniquecode: a,
			tokenuuid: c
		},
		type: "post",
		async: !1,
		timeout: 1E4,
		success: function(a) {
			a = JSON.parse(a);
			var b = Date.parse(new Date);
			$.ajax({
				url: tmpTag ? "https://" + urldomain + "/interfaces/statisticsUserData.do" : "http://" + urldomain + "/interfaces/statisticsUserData.do",
				data: {
					key: a.key,
					secret: a.secret,
					starttime: b,
					statisticsType: "1",
					terminalType: "1",
					channel: "1",
					netWork: "4G",
					region: d,
					udid: "lightapp-rebellion",
					uniquecode: b,
					tokenuuid: c
				},
				type: "post",
				async: !1,
				timeout: 1E4,
				success: function(a) {},
				error: function(a) {}
			})
		},
		error: function(a) {}
	})
};
/**
 * 获取url中"?"符后的字串
 */
function GetRequest() {
	var url = window.location.search;
	var theRequest = new Object();
	if(url.indexOf("?") != -1) {
		var str = url.substr(1);
		strs = str.split("&");
		for(var i = 0; i < strs.length; i++) {
			theRequest[strs[i].split("=")[0]] = (strs[i].split("=")[1]);
		}
	}
	return theRequest;
}