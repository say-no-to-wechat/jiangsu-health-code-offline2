/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var devicestate;
var functionname;
var options;
var jmportal;
var isfinish;
var lightAppJssdk;
if (!lightAppJssdk) lightAppJssdk = {};

var app = {
    // Application Constructor

    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        devicestate = 'deviceready';
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        if (isfinish != 1) {
            implementFunction();
        }

    }
};

function implementFunction() {
    var Exits = isExitsFunction(jmportal);
    if (!Exits || isfinish == 1) {
        return;
    }
    isfinish = 1;
    if (functionname == 'networkType') {
        jmportal.device.getNetworkType(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('networkType error');
        });
    } else if (functionname == 'getUserInfo') {
        jmportal.login.getUserInfo(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('GetUserInfo error');
        });
    } else if (functionname == 'getTicket') {
        jmportal.login.getTicket(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('GetUserInfo error');
        });
    } else if (functionname == 'loginApp') {
        jmportal.login.loginApp(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('LoginApp error');
        });
    } else if (functionname == 'logout') {
        var i = 0;
        jmportal.login.logout(function(data) {
            i = 1;
            options.success(data);
        }, function(data) {
            options.fail('Logout error');
        });
        setTimeout(function() {
            if (i == 0) {
                options.success('注销成功');
            }
        }, 1000);

    } else if (functionname == 'getUUID') {
        jmportal.device.getUUID(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('UUID error');
        });
    } else if (functionname == 'getDistance') {
        jmportal.device.getDistance(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('getDistance error');
        }, options.arg);
    } else if (functionname == 'getLocation') {
        jmportal.device.getLocation(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('location error');
        });
    } else if (functionname == 'chooseImage') {
        if (typeof(options.type) == "undefined") {
            jmportal.camera.chooseImage(function(data) {
                options.success(data);
            }, function(data) {
                options.fail('choose image error');
            }, options.arg, "", 'jssdk1.3');
        } else {
            jmportal.camera.chooseImage(function(data) {
                options.success(data);
            }, function(data) {
                options.fail('choose image error');
            }, options.arg, options.type, 'jssdk1.3');
        }

    } else if (functionname == 'getVideo') {
        jmportal.video.getVideo(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('getVideo error');
        }, 'jssdk1.3');

    } else if (functionname == 'chooseVideoAndPic') {
        jmportal.camera.chooseVideoAndPic(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('choose VideoAndPic error');
        }, 'jssdk1.3');
    } else if (functionname == 'startVoice') {
        jmportal.voice.startVoice(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('start voice error');
        }, 'jssdk1.3');
    } else if (functionname == 'stopVoice') {
        jmportal.voice.stopVoice(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('start voice error');
        }, 'jssdk1.3');
    } else if (functionname == 'playVoice') {
        jmportal.voice.playVoice(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('play voice error');
        }, options.audio, 'jssdk1.3'); //传入要播放的音频文件的路径
    } else if (functionname == 'stopPlayVoice') {
        jmportal.voice.stopPlayVoice(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('stopPlayVoice voice error');
        }, 'jssdk1.3');
    } else if (functionname == 'onSubmit') {
        jmportal.upload.onSubmit(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('onSubmit error');
        });
    }else if (functionname == 'downloadPdf') {
        jmportal.upload.downloadPdf(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('downloadPdf error');
        },options.url,options.fileName);
    }else if (functionname == 'getQRCode') {
        jmportal.QRCode.getQRCode(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('QRCode error');
        });
    } else if (functionname == 'onMenuShare') {
        jmportal.share.onMenuShare(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('share error');
        }, options.arg); //传入分享的参数
    } else if (functionname == 'pay') {
        jmportal.pay.pay(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('pay error');
        }, options.orderNum, options.goodName, options.allPrice, options.orderTime, options.payType);
    } else if (functionname == 'setItem') {
        var i = 0;
        var value = "{\"" + options.key + "\":" + JSON.stringify(options.value) + "}";
        var result = JSON.parse(value);
        jmportal.storage.setItem(function(data) {
            i = 1;
            options.success(data);
        }, function(data) {
            options.fail('setItem error');
        }, options.key, value);

        setTimeout(function() {
            if (i == 0) {
                options.success('保存成功');
            }
        }, 1500);

    } else if (functionname == 'getItem') {
        jmportal.storage.getItem(function(data) {
            var result;
            if (typeof data == 'string') {
                result = JSON.parse(data);
            } else {
                result = data;
            }
            var keyString = options.key;
            options.success(result[keyString]);
        }, function(data) {
            options.fail('getItem error');
        }, options.key);
    } else if (functionname == 'removeItem') {
        var i = 0;
        jmportal.storage.removeItem(function(data) {
            i = 1;
            options.success(data);
        }, function(data) {
            options.fail('removeItem error');
        }, options.key);
        setTimeout(function() {
            if (i == 0) {
                options.success('删除成功');
            }
        }, 1500);
    } else if (functionname == 'showOrHiddenNav') {
        jmportal.showOrHiddenNav.showOrHiddenNav(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('showNav error');
        }, options.isshow, options.url, options.title, options.isgoback);
    } else if (functionname == 'encrypt') {
        jmportal.storage.encrypt(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('encrypt error');
        }, options.data);
    } else if (functionname == 'decrypt') {
        jmportal.storage.decrypt(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('decrypt error');
        }, options.data);
    } else if (functionname == 'callPhone') {
        jmportal.communication.callPhone(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('callPhone error');
        }, options.phone);
    } else if (functionname == 'sendMessage') {
        jmportal.communication.sendMessage(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('sendMessage error');
        }, options.phone);
    } else if (functionname == 'sendEmail') {
        jmportal.communication.sendEmail(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('sendMessage error');
        }, options.email);
    } else if (functionname == 'closeWindow') {
        jmportal.showOrHiddenNav.closeWindow(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('getDistance error');
        });
    } else if (functionname == 'request') {
        jmportal.request.request(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('getDistance error');
        }, options.url, options.data, options.header);
    } else if (functionname == 'alert') {
        jmportal.notification.alert(
            function(data) {
                options.success(data);
            },
            function(data) {
                options.fail('alert error');
            }, options.title, options.message, options.buttonName);
    } else if (functionname == 'confirm') {
        jmportal.notification.confirm(
            function(data) {
                options.success(data);
            },
            function(data) {
                options.fail('confirm error');
            }, options.title, options.message, options.buttonLabels);

    } else if (functionname == 'prompt') {
        jmportal.notification.prompt(
            function(data) {
                options.success(data);
            },
            function(data) {
                options.fail('confirm error');
            }, options.title, options.message, options.buttonLabels);

    } else if (functionname == 'actionSheet') {
        jmportal.notification.actionSheet(
            function(data) {
                options.success(data);
            },
            function(data) {
                options.fail('actionSheet error');
            }, options.title, options.cancelButton, options.otherButtons);
    } else if (functionname == 'showAuthAlert') {
        jmportal.notification.showAuthAlert(
            function(data) {
                options.success(data);
            },
            function(data) {
                options.fail('showAuthAlert error');
            }, options.title, options.cancelButton, options.otherButtons);
    } else if (functionname == 'showPreloader') {
        jmportal.notification.showPreloader(
            function(data) {
                options.success(data);

            },
            function(data) {
                options.fail('showPreloader error');

            }, options.text);
    } else if (functionname == 'hidePreloader') {
        jmportal.notification.hidePreloader(
            function(data) {
                options.success(data);

            },
            function(data) {
                options.fail('hidePreloader error');

            });
    } else if (functionname == 'hidePreloader') {
        jmportal.notification.hidePreloader(
            function(data) {
                options.success(data);

            },
            function(data) {
                options.fail('hidePreloader error');

            });
    } else if (functionname == 'toast') {
        jmportal.notification.toast(
            function(data) {
                options.success(data);
            },
            function(data) {
                options.fail('toast error');
            }, options.text);

    } else if (functionname == 'getjdt') {
        jmportal.getjdt.getjdt(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('getjdt error');
        }, options.url, options.data, options.header);
    } else if (functionname == 'face') {
    	// options.success('{"result":"true"}');
        jmportal.face.beginFace(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('face error');
        }, options.name, options.idnum);
    } else if (functionname == 'liveness') {
        jmportal.face.liveness(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('liveness error');
        });
    } else if (functionname == 'encryptsha1') {
        jmportal.sha.encrypt(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('encrypt error');
        }, options.jsonStr);
    } else if (functionname == 'decryptAES') {
        jmportal.sha.decrypt(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('decrypt error');
        }, options.jsonStr);
    } else if (functionname == "alipay") {
        jmportal.zhifu.alipay(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('alipay error');
        }, options.params, options.clientId);
    } else if (functionname == "wxpay") {
        jmportal.zhifu.wxpay(function(data) {
            options.success(data);
        }, function(data) {
            options.fail('wxpay error');
        }, options.params, options.clientId);
    } else if (functionname == "esscSign") {
        jmportal.card.esscSign(function(data) {
            options.success(data);
        }, function(data) {
            options.fail("esscSign error");
        })
    } else if (functionname == "pay") {
        jmportal.apppay.pay(function(data) {
            options.success(data);
        }, function(data) {
            options.fail("pay error");
        })
    } else if (functionname == "dzzz") {
        jmportal.dzzz.dzzz(function(data) {
            options.success(data);
        }, function(data) {
            options.fail("dzzz error");
        })
    } else if (functionname == "loadimg") {
        jmportal.download.loadimg(function(data) {
            options.success(data);
        }, function(data) {
            options.fail("loadimg error");
        })
    }
};

function isExitsFunction(funcName) {
    if (funcName != undefined) {
        return true;
    } else {
        return false;
    }
};

//工具类
lightAppJssdk.util = (function() {
    //分享
    function share(option) {
        functionname = 'onMenuShare';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.share.onMenuShare(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('share error');
            }, option.arg); //传入分享的参数
        }
    };
    //支付
    function pay(option) {

        functionname = 'pay';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.pay.pay(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('pay error');
            }, option.orderNum, option.goodName, option.allPrice, option.orderTime, option.payType);
        }

    };
    return {
        share: share,
        pay: pay

    }
})();
//请求数据
lightAppJssdk.request = (function() {
    //网络请求
    function request(option) {
        functionname = 'request';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.request.request(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('getDistance error');
            }, option.url, option.data, option.header);
        }
    };
    return {
        request: request

    }
})();

//用户
lightAppJssdk.user = (function() {
    function getTicket(option) {
        functionname = 'getTicket';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.login.getTicket(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('getTicket error');
            });
        }
    };
    //获得用户信息
    function getUserInfo(option) {
        functionname = 'getUserInfo';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.login.getUserInfo(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('GetUserInfo error');
            });
        }
    };

    //登录
    function loginapp(option) {

        functionname = 'loginApp';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            isfinish = 1;
            jmportal.login.loginApp(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('LoginApp error');
            });
        }

    };

    //注销
    function logout(option) {
        functionname = 'logout';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            var i = 0;
            jmportal.login.logout(function(data) {
                i = 1;
                option.success(data);
            }, function(data) {
                option.fail('Logout error');
            });
            setTimeout(function() {
                if (i == 0) {
                    option.success('注销成功');
                }
            }, 1000);

        }

    };
    return {
        getTicket: getTicket,
        getUserInfo: getUserInfo,
        loginapp: loginapp,
        logout: logout
    }

})();
//数据相关
lightAppJssdk.dataUtil = (function() {

    //保存数据
    function setItem(option) {

        functionname = 'setItem';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            var i = 0;
            var value = "{\"" + option.key + "\":" + JSON.stringify(option.value) + "}";
            var result = JSON.parse(value);
            jmportal.storage.setItem(function(data) {
                i = 1;
                option.success(data);
            }, function(data) {
                option.fail('setItem error');
            }, option.key, value);

            setTimeout(function() {
                if (i == 0) {
                    option.success('保存成功');
                }
            }, 1500);
        }

    };

    //读取数据
    function getItem(option) {
        functionname = 'getItem';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.storage.getItem(function(data) {
                var result;
                if (typeof data == 'string') {
                    result = JSON.parse(data);
                } else {
                    result = data;
                }
                var keyString = option.key;
                option.success(result[keyString]);
            }, function(data) {
                option.fail('getItem error');
            }, option.key);

        }

    };

    //删除数据
    function removeItem(option) {

        functionname = 'removeItem';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            var i = 0;
            jmportal.storage.removeItem(function(data) {
                i = 1;
                option.success(data);
            }, function(data) {
                option.fail('removeItem error');
            }, option.key);
            setTimeout(function() {
                if (i == 0) {
                    option.success('删除成功');
                }
            }, 1500);
        }

    };
    //加密数据
    function encrypt(option) {

        functionname = 'encrypt';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.storage.encrypt(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('encrypt error');
            }, option.data);

        }

    };
    //解密数据
    function decrypt(option) {

        functionname = 'decrypt';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.storage.decrypt(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('decrypt error');
            }, option.data);
        }

    };
    return {
        setItem: setItem,
        getItem: getItem,
        removeItem: removeItem,
        encrypt: encrypt,
        decrypt: decrypt
    }
})();
//页面控制
lightAppJssdk.navigation = (function() {
    //页面控制
    function show(option) {
        functionname = 'showOrHiddenNav';
        if (typeof jmportal == 'undefined') {
            option.isshow = '0';
            options = option;
            implementFunction();
        } else {
            jmportal.showOrHiddenNav.showOrHiddenNav(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('showNav error');
            }, '0', option.url, option.title, option.isgoback);
        }
    };

    function hide(option) {
        functionname = 'showOrHiddenNav';
        if (typeof jmportal == 'undefined') {
            option.isshow = '1';
            option.isgoback = '';
            option.title = '';
            options = option;
            implementFunction();
        } else {
            jmportal.showOrHiddenNav.showOrHiddenNav(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('showNav error');
            }, '1', option.url, '', '');
        }
    };
    //关闭当前窗口
    function close(option) {
        functionname = 'closeWindow';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.showOrHiddenNav.closeWindow(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('getDistance error');
            });

        }
    };
    return {
        show: show,
        hide: hide,
        close: close
    }

})();
//媒体资源
lightAppJssdk.media = (function() {
    //选取图片
    function chooseImage(option) {
        functionname = 'chooseImage';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            if (typeof(option.type) == "undefined") {
                jmportal.camera.chooseImage(function(data) {
                    option.success(data);
                }, function(data) {
                    option.fail('choose image error');
                }, option.arg, "", 'jssdk1.3');
            } else {
                jmportal.camera.chooseImage(function(data) {
                    option.success(data);
                }, function(data) {
                    option.fail('choose image error');
                }, option.arg, option.type, 'jssdk1.3');
            }

        }

    };
    //选取视频
    function chooseVideo(option) {
        functionname = 'getVideo';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.video.getVideo(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('getVideo error');
            }, 'jssdk1.3');

        }
    };
    //综合媒体
    function chooseVideoAndPic(option) {
        functionname = 'chooseVideoAndPic';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.camera.chooseVideoAndPic(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('choose VideoAndPic error');
            }, 'jssdk1.3');

        }
    };

    //音频
    function startVoice(option) {
        functionname = 'startVoice';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.voice.startVoice(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('start voice error');
            }, 'jssdk1.3');
        }
    };

    function stopVoice(option) {
        functionname = 'stopVoice';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.voice.stopVoice(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('start voice error');
            }, 'jssdk1.3');
        }
    };

    function playVoice(option) {
        functionname = 'playVoice';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.voice.playVoice(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('play voice error');
            }, option.audio, 'jssdk1.3'); //传入要播放的音频文件的路径

        }
    };

    function stopPlayVoice(option) {
        functionname = 'stopPlayVoice';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.voice.stopPlayVoice(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('stopPlayVoice voice error');
            }, 'jssdk1.3');
        }
    };

    return {
        chooseImage: chooseImage,
        chooseVideo: chooseVideo,
        chooseVideoAndPic: chooseVideoAndPic,
        startVoice: startVoice,
        stopVoice: stopVoice,
        playVoice: playVoice,
        stopPlayVoice: stopPlayVoice,
    }
})();

lightAppJssdk.upload = (function() {
	function onSubmit(option) {
	    functionname = 'onSubmit';
	    if (typeof jmportal == 'undefined') {
	        implementFunction(option);
	    } else {
	        jmportal.upload.onSubmit(function(data) {
	            option.success(data);
	        }, function(data) {
	            option.fail('onSubmit error');
	        });
	    }
	};
	
	function downloadPdf(option) {
	    functionname = 'downloadPdf';
	    if (typeof jmportal == 'undefined') {
	        options = option;
	        implementFunction();
	    } else {
	        jmportal.upload.downloadPdf(function(data) {
	            option.success(data);
	        }, function(data) {
	            option.fail('downloadPdf error');
	        }, option.url, option.fileName); 
	    }
	};
	return {
		onSubmit: onSubmit,
		downloadPdf : downloadPdf
	}
})();


//设备
lightAppJssdk.device = (function() {
    function call(option) {
        functionname = 'callPhone';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.communication.callPhone(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('callPhone error');
            }, option.phone);
        }
    };

    function mail(option) {
        functionname = 'sendEmail';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.communication.sendEmail(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('sendMessage error');
            }, option.email);
        }
    };

    function message(option) {

        functionname = 'sendMessage';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.communication.sendMessage(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('sendMessage error');
            }, option.phone);
        }
    };

    function uuid(option) {
        functionname = 'getUUID';
        options = option;
        implementFunction();
    };

    function networkType(option) {
        functionname = 'networkType';
        options = option;
        implementFunction();
    };

    function scan(option) {
        functionname = 'getQRCode';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.QRCode.getQRCode(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('QRCode error');
            });
        }

    };
    return {
        call: call,
        mail: mail,
        message: message,
        uuid: uuid,
        networkType: networkType,
        scan: scan
    }
})();
//位置
lightAppJssdk.map = (function() {
    function getLocation(option) {
        functionname = 'getLocation';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.device.getLocation(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('location error');
            });

        }

    };

    function getDistance(option) {
        functionname = 'getDistance';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.device.getDistance(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('getDistance error');
            }, option.arg);
        }
    };
    return {
        getLocation: getLocation,
        getDistance: getDistance
    }
})();

// 弹窗
lightAppJssdk.notification = (function() {
    function alert(option) {
        functionname = 'alert';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.notification.alert(
                function(data) {
                    option.success(data);
                },
                function(data) {
                    option.fail('alert error');
                }, option.title, option.message, option.buttonName);
        }
    };

    function confirm(option) {
        functionname = 'confirm';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.notification.confirm(
                function(data) {
                    option.success(data);
                },
                function(data) {
                    option.fail('confirm error');
                }, option.title, option.message, option.buttonLabels);
        }
    };

    function prompt(option) {

        functionname = 'prompt';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.notification.prompt(
                function(data) {
                    option.success(data);
                },
                function(data) {
                    option.fail('prompt error');
                }, option.title, option.message, option.buttonLabels);
        }

    };

    function actionSheet(option) {
        functionname = 'actionSheet';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.notification.actionSheet(
                function(data) {
                    option.success(data);
                },
                function(data) {
                    option.fail('actionSheet error');
                }, option.title, option.cancelButton, option.otherButtons);
        }
    };
	
	function showAuthAlert(option) {
	    functionname = 'showAuthAlert';
	    if (typeof jmportal == 'undefined') {
	        options = option;
	        implementFunction();
	    } else {
	        jmportal.notification.showAuthAlert(
	            function(data) {
	                option.success(data);
	            },
	            function(data) {
	                option.fail('showAuthAlert error');
	            });
	    }
	};

    function showPreloader(option) {

        functionname = 'showPreloader';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.notification.showPreloader(
                function(data) {
                    option.success(data);

                },
                function(data) {
                    option.fail('showPreloader error');

                }, option.text);

        }
    };

    function hidePreloader(option) {
        functionname = 'hidePreloader';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.notification.hidePreloader(
                function(data) {
                    option.success(data);

                },
                function(data) {
                    option.fail('hidePreloader error');

                });

        }
    };

    function toast(option) {
        functionname = 'toast';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.notification.toast(
                function(data) {
                    option.success(data);
                },
                function(data) {
                    option.fail('toast error');
                }, option.text);

        }
    };

    return {
        alert: alert,
        confirm: confirm,
        prompt: prompt,
        actionSheet: actionSheet,
        showPreloader: showPreloader,
        hidePreloader: hidePreloader,
        toast: toast,
		showAuthAlert: showAuthAlert
    }

})();

//人脸识别
lightAppJssdk.face = (function() {
    //唇语识别
    function face(option) {
		
        functionname = 'face';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
        	// option.success('{"result":"true"}');
            jmportal.face.beginFace(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('face error');
            }, option.name, option.idnum);
        }
    };
    //活体检测
    function liveness(option) {
        functionname = 'liveness';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.face.liveness(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('liveness error');
            });
        }
    };
    
    return {
        face: face, 
        liveness: liveness
    }
})();

//sha1加密
lightAppJssdk.encrypt = (function() {

    function encrypt(option) {
        functionname = 'encryptsha1';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.sha.encrypt(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('encrypt error');
            }, option.jsonStr, option.pkey);
        }
    };

    function decrypt(option) {
        functionname = 'decryptAES';
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.sha.decrypt(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('decrypt error');
            }, option.jsonStr);
        }
    };
    return {
        encrypt: encrypt,
        decrypt: decrypt

    }
})();
//获得jdt
function getjdt(option) {
    functionname = 'getjdt';
    options = option;
    implementFunction();
};

lightAppJssdk.zhifu = (function() {
    //支付宝支付
    function alipay(option) {
        functionname = "alipay";
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.zhifu.alipay(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('alipay error');
            }, option.params, option.clientId);
        }
    }
    //微信支付
    function wxpay(option) {
        functionname = "wxpay";
        if (typeof jmportal == 'undefined') {
            options = option;
            implementFunction();
        } else {
            jmportal.zhifu.wxpay(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('wxpay error');
            }, option.params, option.clientId);
        }
    };
    return {
        alipay: alipay,
        wxpay: wxpay
    }
})()
lightAppJssdk.card = (function() {
    function esscSign(option) {
        functionname = "esscSign";
        if (typeof jmportal == "undefined") {
            options = option;
            implementFunction();
        } else {
            jmportal.card.esscSign(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('esscSign error');
            }, option.name, option.cardid, option.uuid)
        }
    };
    return {
        esscSign: esscSign,
    }
})()
lightAppJssdk.apppay = (function() {
    function pay(option) {
        functionname = "pay";
        if (typeof jmportal == "undefined") {
            options = option;
            implementFunction();
        } else {
            jmportal.apppay.pay(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('pay error');
            }, option.params, option.paychannel)
        }
    };
    return {
        pay: pay,
    }
})()
lightAppJssdk.dzzz = (function() {
    function dzzz(option) {
        functionname = "dzzz";
        if (typeof jmportal == "undefined") {
            options = option;
            implementFunction();
        } else {
            jmportal.dzzz.dzzz(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('dzzz error');
            }, option.params, option.channel)
        }
    };
    return {
        dzzz: dzzz,
    }
})()
lightAppJssdk.download = (function() {
    function loadimg(option) {
        functionname = "loadimg";
        if (typeof jmportal == "undefined") {
            options = option;
            implementFunction();
        } else {
            jmportal.download.loadimg(function(data) {
                option.success(data);
            }, function(data) {
                option.fail('loadimg error');
            }, option.loadurl)
        }
    };
    return {
        loadimg: loadimg,
    }
})()

// //人脸识别
// function face(option) {
// 	functionname = 'face';
//  options = option;
//  implementFunction();
// }
app.initialize();