var u = navigator.userAgent,
	app = navigator.appVersion;
var ishttps = 'https:' == document.location.protocol ? true : false;
var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Linux') > -1; //android终端或者uc浏览器
var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端

if(isiOS) {
	if(tmpTag == true) {

		document.write('<script type="text/javascript" src="https://' + urldomain + '/jssdk/cordova_ios.js"></script>');

	} else {
		document.write('<script type="text/javascript" src="http://' + urldomain + '/jssdk/cordova_ios.js"></script>');

	}
} else {
	if(u.substring(u.length - 5, u.length) == '1.4.2') {
		if(tmpTag == true) {
			document.write('<script type="text/javascript" src="https://' + urldomain + '/jssdk/cordova_android1.4.2.js"></script>');

		} else {
			document.write('<script type="text/javascript" src="http://' + urldomain + '/jssdk/cordova_android1.4.2.js"></script>');

		}
	} else {
		if(tmpTag == true) {

			document.write('<script type="text/javascript" src="https://' + urldomain + '/jssdk/cordova_android.js"></script>');

		} else {
			document.write('<script type="text/javascript" src="http://' + urldomain + '/jssdk/cordova_android.js"></script>');

		}

	}
}