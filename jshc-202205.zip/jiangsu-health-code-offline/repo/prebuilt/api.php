<?php header('Access-Control-Allow-Origin: *');  ?>

<?php
// Set all your variables here! 
$NAME = '喜禁评';
$IDCARD = '323******791';
$PHONE = '153****3072';
// You can also modify more API responses below if you want. 
?>

<?php
// All APIs in the same script. 

if(isset($_GET["api"])) {
    $api = validatyInput($_GET["api"]);
    $res = '';
    switch($api) {
        case "/jkm/2/checkXcYzm":
            $res = '{"res":{"value":"1"},"resMessage":"OK","resCode":0}';
            break;

        case "/jkm/2/queryClockInCount":
            $res = '{"resMessage":"OK","resCode":0,"res":{"commitCount_day":0}}';
            break;

        case "/jkm/2/queryDrHs":
            $res = '{"resMessage":"OK","resCode":0,"res":{"expires":"7200","url":"https://jshscx.jsehealth.com:8002/app/#/?secret=1"}}';
            break;

        case "/jkm/2/queryGjm":
            $res = '{"resMessage":"OK","resCode":0,"res":{"head":{"message":"接口调用成功","status":"0"},"currentTime":PLACEHOLDER_TIMESTAMP,"data":{"ktjc":{},"yqDatas":[],"hasReport":false,"yqReports":[],"yqWarn":{"warnType":"无"},"hsjc":{"hsjcsj":"2020-05-21","hsjcjgmc":"无锡市人民医院","hsjcjg":"阴性"},"healthyReport":[{"date":"2022-04-01","healthyId":"111-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx","healthyStaus":"00","cdTimeVersion":1,"dataSource":"江苏省"},{"date":"2020-06-13","reason":"未命中任何规则","healthyId":"111-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx","healthyStaus":"00","cdTimeVersion":8,"dataSource":"湖北省"}],"person":{"desensitizeCardId":"PLACEHOLDER_IDCARD","desensitizeName":"PLACEHOLDER_NAME"},"xcgj":[],"rjcx":[]}}}';
            break;

        case "/jkm/2/queryHskt":
            $res = '{"res":{"currentTime":PLACEHOLDER_TIMESTAMP,"kt":{"msg":"查询成功","data":"","status":"0"},"hs":{"msg":"查询成功","data":{"hsjcsj":"PLACEHOLDER_PCRTIME:00","hsjcjgmc":"无锡市人民医院","hsjcjg":"阴性"},"status":"0"}},"resMessage":"OK","resCode":0}';
            break;

        case "/jkm/2/queryQrCode":
            $res = '{"AuthorNote":"这是国家防疫健康码的信息，不是苏康码", "resMessage":"OK","resCode":0,"res":{"qrCode":"The_Content_Of_Your_QRCode_Is_Here","imgStream":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"}}';
            break;

        case "/jkm/2/queryTip":
            $res = '{"resMessage":"OK","resCode":0,"res":{"track_matching":true,"tip":"绿色：勤洗手、常通风、戴口罩，出现发热咳嗽等症状请及时就医","rxjjgl":0}}';
            break;

        case "/jkm/2/queryUserInfo":
            // The `info` struct is not used at all. Currently no need to mock it, so I just set it to null. 
            $res = '{"resMessage":"OK","resCode":0,"res":{"cityNo":"320000","abc":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","idType":"1","level":"lCNvATW25TYP0nW4643aE1Tp/WF3SaaTBeJ2OvEoUYo=","commitCount":0,"idcardNo":"PLACEHOLDER_IDCARD","cityData":false,"scanFlag":"ODA2YWJhOCAgY29ubmVjdF92bS5zaAoWJhOCAgY29ub%3D","zjgxsj":"2020-07-18 10:00:08","extInfo":{},"remainDays":null,"currentTime":PLACEHOLDER_TIMESTAMP,"originReason":"","qrCode":"V513e495993e97d768fe993fb04051d2e7c20000","phone":"PLACEHOLDER_PHONE","idcardType":"IDENTITY_CARD","name":"PLACEHOLDER_NAME","qrCodeText":"https://h5.dingtalk.com/healthAct/index.html?qrCode=V513e495993e97d768fe993fb04051d2e7c20000#/result","commitCount_day":0,"exceed14Day":false,"info":null}}';
            break;

        case "/jkm/2/queryVaccine":
            $res = '{"resMessage":"OK","resCode":0,"res":{"msg":"未查询到新冠接种信息！","currentTime":PLACEHOLDER_TIMESTAMP,"data":null,"success":false}}';
            break;

        case "/jkm/2/queryXc":
            $res = '{"resMessage":"OK","resCode":0,"res":{"value":"-1"}}';
            break;

        case "/jkm/2/queryXcYzm":
            $res = '{"res":{"msg":"查询成功","data":{"result":"短信发送中,请注意查收","code":"00","errorDesc":"请求成功","status":"1","queryId":"11111111111111111"},"status":"0"},"resMessage":"OK","resCode":0}';
            break;

        case "/jkm/2/saveRiskReport":
            $res = '{"resMessage":"OK","resCode":0,"res":null}';
            break;

        case "/jkm/2/userAuth_token":
            $res = '{"resMessage":"OK","resCode":0,"res":{"userdetail":{"abc":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","cardid":"PLACEHOLDER_IDCARD","sex":"0","mAbc":"11111","mobile":"PLACEHOLDER_PHONE","name":"PLACEHOLDER_NAME","uuid":"P202007129387568123658123","paperstype":"1","qwe":"11111"},"version":"V2022031401"}}';
            break;

        case "/healthCode/queryYmStatus":
            $res = '{"resMessage":"OK","resCode":0,"res":{"currentTime":PLACEHOLDER_TIMESTAMP,"ymStatus":"1"}}'; /*-1=No information, 1=Fully vaccined*/
            break;
        case "/healthCode/queryHs":
        case "/healthCode/queryLatestHs":
            $res = '{"res":{"currentTime":PLACEHOLDER_TIMESTAMP,"hs":{"area":"苏州市玄武区","collectTime":"PLACEHOLDER_PCRTIME","collectUnit":"苏州市人民医院","collectCity":"苏州市","checkResult":"阴性","checkUnit":"苏州市人民医院"}},"resMessage":"OK","resCode":0}';
            break;

        default:
            $res = "ERROR: GET parameter 'api=$api' not valid. ";
    }
    $res = str_replace('PLACEHOLDER_TIMESTAMP', strval(time()), $res);
    $res = str_replace('PLACEHOLDER_PCRTIME', strval(date("Y-m-d 15:00", time() + 8*60*60 - 24*60*60)), $res); /*At 15:00 yesterday, UTC+8*/
    $res = str_replace('PLACEHOLDER_IDCARD', $IDCARD, $res);
    $res = str_replace('PLACEHOLDER_PHONE', $PHONE, $res);
    $res = str_replace('PLACEHOLDER_NAME', $NAME, $res);
    echo $res;
}
else {
    echo "ERROR: GET paramter 'api' is not set. ";
}


function validatyInput($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

