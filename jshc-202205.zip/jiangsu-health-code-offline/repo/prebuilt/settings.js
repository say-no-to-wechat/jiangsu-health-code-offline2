// You can use any tool you like, to provide the mocked_api. 
function offical_api_addr(url) { return 'https://jsstm.jszwfw.gov.cn' + url; }
function mocked_api_addr(url) { return 'https://your-website.com/this-project/api.php?api=' + url + '&more='; }
var offical_api_method = "post";
var mocked_api_method = "get";

var _api_addr = mocked_api_addr;
var _api_method = mocked_api_method; 

