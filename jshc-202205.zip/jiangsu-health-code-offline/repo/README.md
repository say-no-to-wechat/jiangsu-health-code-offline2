
# How to build this project from stretch (or pull the latest upgrade)

```
# document: how to fuck this website from stretch
# 1. run smart-deps-download.sh to download all resources, and apply all patch. 
# 2. (seems unnecessary) Modify ./dist/common1111111111.js: set apiUrl to empty: `var apiUrl=""`. 
# 3. Put this directory to a web server with PHP enabled. 
#      you can modify the api.php if you want to adjust the behavior. 
#    Also modify settings.js to set the web path to api.php. 
# 4. Visit https://your-website.com/xxx/jkmIndex.html?token=1
# 5. Fix all missing resources. You need to fix all 404 errors in browser. you can see 404 errors in browser -> F12 -> networking
```

