#!/bin/bash
ua='Mozilla/5.0 (Linux; Android 8.1.0; Redmi 5 Build/OPM1.171019.026; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/71.0.3578.99 Mobile Safari/537.36 NebulaSDK/1.8.100112 Nebula AlipayDefined(nt:WIFI,ws:360|0|2.0,ac:sp) useStatusBar/true isConcaveScreen/false mPaaSClient'

echo '
############## 1. download index ################'

function fetch_jkmindex () {
    # not using html-beautify
    # jkmIndex: always overwrite because it always update. 
    curl --user-agent "$ua" https://jsstm.jszwfw.gov.cn/jkmIndex.html -o jkmIndex.html &&
    sed -i 's/<title>/<script src="settings.js"><\/script>&/g' jkmIndex.html
}

fetch_jkmindex || exit $?

echo '
############## 2. download all resources ################'

echo 'Note: error 405 means your IP is blocked by fucking aliyun. '

# We starts here
todos="jkmIndex.html"

function curlw () {
    # Add some options for every curl request, basing on config file.
    curl_options=( -L --user-agent "$ua" -s --max-time 30 ) # Old version of curl failed to fallback to http1.1 on http2 error.

    exec 3>&1
    HTTP_STATUS=$(curl -w "%{http_code}" -o >(cat >&3) "${curl_options[@]}" "$@") || return $?
    [[ "$HTTP_STATUS" == 40* ]] || [[ "$HTTP_STATUS" == 50* ]] && echo "HTTP Error $HTTP_STATUS" 1>&2 && return 2
    return 0
}

function download_if_not_exist () {
    local fname="$1"
    echo "DEBUG: downloading $fname if not exist..."

    # Only skip if exists and size greater than 0
    [[ -s "$fname" ]] && return 0
    mkdir -p `dirname "$fname"`
    curlw "https://jsstm.jszwfw.gov.cn/$fname" > "$fname" && return 0
    curlw "https://www.jszwfw.gov.cn/jmopen/$fname" > "$fname" && ! grep accs_404 "$fname" && return 0

    # Failed. 
    grep -F '您的访问被阻断' "$fname" && echo '这个死妈玩意不让所有境外IP访问，生怕他妈死了的消息让外国人知道'
    rm -f "$fname"
    echo "Failed to download $fname"
    return 2
}

while true; do
    curr_fl=`echo -n "$todos" | head -n 1`
    [[ -z "$todos" ]] && break # nothing else to be done
    todos=`echo -n "$todos" | tail -n +2`
    [[ -z "$curr_fl" ]] && continue # skip empty line

    download_if_not_exist "$curr_fl" || continue
    sed -i 's/\.gov\.cn/.gov-cn-blocked.au/g' "$curr_fl"
    sed -i 's/\.baidu\.com/.baidu-com-blocked.au/g' "$curr_fl"
    sed -i 's/\.qq\.com/.qq-com-blocked.au/g' "$curr_fl"

    # Iterate js and html for more, and iterate css for images
    if [[ "$curr_fl" == *".html" ]] || [[ "$curr_fl" == *".js" ]] || [[ "$curr_fl" == *".css" ]]; then
        childs=`cat "$curr_fl" | grep -v '// file: ' | grep -oE '([a-zA-Z0-9\._-]+/)+[a-zA-Z0-9\._-]+\.(js|css|png|gif|jpe?g)' | grep -vE '[\.-](com|cn|gov|blocked.au)' | sed 's/^\.*\///g'`
        todos=`printf "%s\n%s" "$todos" "$childs"`
    fi
done

echo '
############# 3. Fix known missing files #############'

download_if_not_exist plug/layer/skin/layer.css

echo '
############## 4. patch #############'

fname=`echo dist/skm*.min.js`
if ! grep -o 'Already patched - 1e0fdd9305a1' "$fname"; then
    echo "Patching $fname..."
    sed -i 's/{url:"/{url:_api_addr("/g' "$fname"
    sed -i 's/{url:[^,]*/&)/g' "$fname"
    sed -i 's/,type:[^,]*/,type:_api_method/g' "$fname"
    echo '/*Already patched - 1e0fdd9305a1*/' >> "$fname"
fi
fname=plug/dahan/jsdk.js
if ! grep -o 'Already patched - 1e0fdd9305a1' "$fname"; then
    # There should be a jmopen in the path, but we removed it. 
    echo "Patching $fname..."
    sed -i 's/http:... . urldomain . .\///g' "$fname"
    sed -i 's/https:... . urldomain . .\///g' "$fname"
    echo '/*Already patched - 1e0fdd9305a1*/' >> "$fname"
fi


echo '
############# 5. copy api.php and settings.js #############'

function get_script_loc () {
    whichscript="$1"
    while [ -h "$whichscript" ]; do
        tmpd="$(cd -P "$(dirname "$whichscript")" && pwd)"
        whichscript="$(readlink "$whichscript")"
        [[ $whichscript != /* ]] && whichscript="$tmpd/$whichscript"
    done
    tmpd="$(cd -P "$(dirname "$whichscript")" && pwd)"
    echo -n "$tmpd"
}
tres=`type -p "$0"`
[[ -z "$tres" ]] && pref=`get_script_loc "$0"` || pref=`get_script_loc "$tres"`

[[ -f api.php ]] || cp "$pref/api.php" . || echo 'Failed to copy'
[[ -f settings.js ]] || cp "$pref/settings.js" . || echo 'Failed to copy'

