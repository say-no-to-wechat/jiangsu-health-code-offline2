# Jiangsu health code Offline / Self-Hosted [苏康码]

## If you just want to access the health code without Alipay/Wechat, follow this guide:

1. Setup an SSL capture software on your Android phone. I'm using [NetCapture](https://play.google.com/store/apps/details?id=com.minhui.networkcapture&hl=en_US&gl=US)

2. Install the software and its fake certificate, start the VPN, then open your health code from Alipay. You can see a HTTPS GET request like this:

```
https://jsstm.jszwfw.gov.cn/jkmIndex.html?token=03c948cb7ce13d3be3f9d0f0023b524bc767a0c9aaf7c7dbbcf6c5ba778ce333&uuid=P202007129387568123658123&uid=1238956192882571
```

Just save the URL in your phone. You're all set! Just access your health code with ANY browser.

## If you want to save your health-code, and self-host it. Use my project!

1. Clone this project and put the `prebuilt` directory into your web server. You should have PHP enabled for api.php. (You can also implement the mocked_api with other tools, like python, go, ...) 

2. Modify `settings.js` to set the URL root. Also modify `api.php` to set your name, idcard, phone number, etc. 

3. Now we have a green health code at `https://.../index.html?token=1`, but...

## If you want to allow your self-hosted health code to be scanned, let's continue. 

Open your real Jiangsu health code from Alipay. Scan it with a good QR decoder, and the URL looks like this:

```
https://h5.dingtalk.com/healthAct/index.html?qrCode=V513e495993e97d768fe993fb04051d2e7c20000&b=ODA2YWJhOCAgY29ubmVjdF92bS5zaAoWJhOCAgY29ub%3D#/result
```

> Just a note: I strongly believe that the parameter `b` is not recognized by dingtalk at all. (Jiangsu gov website query dingtalk for the url, then add a b=... param to it. ) 
I believe this param is just to make QR code looks random, but I can not verify it. 

Now modify the queryUserInfo in api.php, set `scanFlag` to the value of b, set `qrCode` to the value of qrCode, and optionally set `qrCodeText` with its format. 

In this example, we should have `"scanFlag":"ODA2YWJhOCAgY29ubmVjdF92bS5zaAoWJhOCAgY29ub%3D",` and `"qrCode":"V513e495993e97d768fe993fb04051d2e7c20000"` and `"qrCodeText":"https://h5.dingtalk.com/healthAct/index.html?qrCode=V513e495993e97d768fe993fb04051d2e7c20000&b=ODA2YWJhOCAgY29ubmVjdF92bS5zaAoWJhOCAgY29ub%3D#/result"`

Ok. Now don't be afraid to these police, and show your code!

## Further more, I also want my `国家防疫健康码` to be valid.

Scan your existing national health code, and the result looks like a long random base64-encoded data. Fill the data in `"qrCode"` field of `queryQrCode` in api.php. 

## Demo

All tokens in this repo are randomly generated, from the same format. 

![](img/1.png)

![](img/2.png)

![](img/3.png)

